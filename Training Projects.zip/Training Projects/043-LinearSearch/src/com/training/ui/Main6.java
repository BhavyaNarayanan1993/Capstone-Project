package com.training.ui;

import java.util.Comparator;

import com.training.model.BillItem;
import com.training.model.comparators.BillItemPriceComparator;
import com.training.model.comparators.BillItemQuantityComparator;

public class Main6 {

	private static int search(BillItem[] arr, BillItem searchObject) {

		for (int i = 0; i < arr.length; i++) {
			if (searchObject instanceof Comparable) {
				Comparable searchData = searchObject;
				int r = arr[i].compareTo(searchData);
				if (r == 0)
					return i;
			}
		}
		return -1;
	}

	private static int quantitySearch(BillItem[] arr, BillItem searchObject) {
		Comparator comparator = new BillItemQuantityComparator();
		for (int i = 0; i < arr.length; i++) {
			int r = comparator.compare(arr[i], searchObject);
			if (r == 0)
				return i;
		}
		return -1;
	}

	private static int priceSearch(BillItem[] arr, BillItem searchObject) {
		Comparator comparator = new BillItemPriceComparator();
		for (int i = 0; i < arr.length; i++) {
			int r = comparator.compare(arr[i], searchObject);
			if (r == 0)
				return i;
		}
		return -1;
	}

	public static void main(String[] args) {

		BillItem[] billItems = { new BillItem("Samsung", 2, 15000.00), 
								new BillItem("Nokia", 5, 12000.00),
								new BillItem("Iphone", 5, 78000.00), 
								new BillItem("Oppo", 4, 32000.00),
								new BillItem("Redmi", 7, 44000.00),
								new BillItem("Vivo", 1, 49000.00)};

		BillItem searchObject = new BillItem("Iphone", 5, 49000.00);
		int searchResult = search(billItems, searchObject);
		if (searchResult == -1)
			System.out.println("Search Data not found");
		else
			System.out.println("Search element " + searchObject + " found in position:" + searchResult);

		
		System.out.println("------Quantity Search--------");
		int qSearchResult = quantitySearch(billItems, searchObject);
		if (qSearchResult == -1)
			System.out.println("Search Data not found");
		else
			System.out.println("Search element " + searchObject + " found in position:" + qSearchResult);

		
		System.out.println("------Price Search--------");
		int pSearchResult = priceSearch(billItems, searchObject);
		if (pSearchResult == -1)
			System.out.println("Search Data not found");
		else
			System.out.println("Search element " + searchObject + " found in position:" + pSearchResult);
	}

}