package com.training.ui;

import com.training.model.BillItem;

public class Main4 {

	public static void main(String[] args) {
		BillItem item1=new BillItem("Dell laptop", 3, 20000.0);
		BillItem item2=new BillItem("Iphone", 4, 40000.0);
		
		int r=item1.compareTo(item2);
		System.out.println(r);
		
		if(r<0)
			System.out.println("Invoking object is less than parameter object");
		if(r>0)
			System.out.println("Invoking object is higher than parameter object");
		if(r==0)
			System.out.println("Invoking object is same as parameter object");

	}

}
