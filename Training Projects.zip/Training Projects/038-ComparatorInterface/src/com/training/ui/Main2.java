package com.training.ui;

import com.training.model.BillItem;
import com.training.model.comparators.BillItemPriceComparator;

public class Main2 {

	public static void main(String[] args) {
		
		BillItem billItem1=new BillItem("DELL",12,49000.00);
		BillItem billItem2=new BillItem("IPhone",10,49000.00);
		
		BillItemPriceComparator comparator=new BillItemPriceComparator();
		int r= comparator.compare(billItem1, billItem2);
		System.out.println(r);
		
		if(r<0)
			System.out.println("Bill item 1 is less than bill item 2");
		if(r>0)
			System.out.println("Bill item 1 is greater than bill item 2");
		if(r==0)
			System.out.println("Bill item 1 is equal to bill item 2");
		

	}

}
