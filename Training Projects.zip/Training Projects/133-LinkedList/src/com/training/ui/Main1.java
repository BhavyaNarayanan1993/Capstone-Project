package com.training.ui;

import java.awt.print.Printable;
import java.util.List;

import com.training.linkedlist.LinkedList;
import com.training.model.Customer;

public class Main1 {

	public static void main(String[] args) {
		LinkedList<Customer> customerList=new LinkedList<Customer>();
		Customer customer1=new Customer(1, "Manu");
		Customer customer2=new Customer(2, "Surya");
		Customer customer3=new Customer(3, "Meenu");
		Customer customer4=new Customer(4, "Raj");
		Customer customer5=new Customer(5, "Ram");
		
		customerList.addToList(customer1);
		customerList.addToList(customer2);
		customerList.addToList(customer3);
		customerList.addToList(customer4);
		customerList.addToList(customer5);
		
		customerList.print();
		
		System.out.println("Count= "+customerList.count());
		
		Customer customer6= new Customer(6, "Karthik");
		customerList.insertAfter(customer3, customer6);
		customerList.print();

	}

}
