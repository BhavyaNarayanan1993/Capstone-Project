package com.training.model;

public class Square{
		private int size;

		public Square(int size) {
			super();
			this.size = size;
		}

		/*
		 * @Override public int compareTo(Object o) { Square other=(Square)o;
		 * if(this.size>other.size) return 1; if(this.size<other.size) return -1; return
		 * 0; }
		 */

		public int getSize() {
			return size;
		}

		public void setSize(int size) {
			this.size = size;
		}

		@Override
		public String toString() {
			return "\nSquare [size=" + size + "]";
		}

		
		
		public int getArea() {
			return this.size*this.size;
		}

		
}
