package pack2;

public class J extends I{
	

}
