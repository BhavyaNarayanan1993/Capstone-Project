package pack3;

import pack2.Employee;

public class Main2 {

	public static void main(String[] args) {

		Employee emp=new Employee();
		emp.setId(101);
		emp.setName("Manu");
		emp.setBasicSalary(1000);
		emp.setGrade('A');
		
		System.out.println(emp.computeAllowance());
		System.out.println(emp.computeTax());
		System.out.println(emp.computeNetSalary());
		
		System.out.println("-----------------------------------");
		
		Employee emp2=new Employee(102,"Nirmala",2000,'A');
		System.out.println(emp2.computeAllowance());
		System.out.println(emp2.computeTax());
		System.out.println(emp2.computeNetSalary());
		
		System.out.println("-----------------------------------");

	}

}
