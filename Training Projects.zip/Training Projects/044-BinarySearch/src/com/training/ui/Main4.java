package com.training.ui;

import java.util.Arrays;

import com.training.model.Square;

public class Main4 {
	
	private static int search(Square[] arr,Square searchData) {
		
		int low=0,high=arr.length-1;
		while(low<=high) {
			int mid=low+(high-low)/2;
			int r=arr[mid].compareTo(searchData);
			if(r==0) 
				return mid;
			else if(r<0)
				low=mid+1;
			else
				high=mid-1;
		}
		return -1;
	}

	public static void main(String[] args) {
		Square[] squares=new Square[5];
		
		Square sq1=new Square(34);
		Square sq2=new Square(15);
		squares[0]=sq1;
		squares[1]=sq2;
		squares[2]=new Square(16);
		squares[3]=new Square(27);
		squares[4]=new Square(97);
		
		Square searchObject=new Square(97);
		
		Arrays.sort(squares);
		System.out.println(Arrays.toString(squares));
		
		int searchResult=search(squares, searchObject);
		
		if(searchResult==-1)
			System.out.println(searchObject+"  not found in the array and the result is "+searchResult);
		else
			System.out.println(searchObject+"  found in the array and the position is "+searchResult);
	}

}
