package com.training.ui;

import com.training.ds.IntegerStack;

public class Main5 {

	public static void main(String[] args) {
		IntegerStack stack=new IntegerStack(5);
		stack.push(Integer.valueOf(100));
		stack.push(Integer.valueOf(200));
		stack.push(Integer.valueOf(300));
		stack.push(Integer.valueOf(400));
		stack.push(Integer.valueOf(500));
		
		System.out.println(stack);
		
		Integer r=stack.pop();
		System.out.println(r);
		System.out.println(stack);
		
		r=stack.pop();
		System.out.println(r);
		System.out.println(stack);
		
		r=stack.pop();
		System.out.println(r);
		System.out.println(stack);

	}

}
