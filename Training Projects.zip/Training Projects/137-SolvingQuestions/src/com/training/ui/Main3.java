package com.training.ui;

public class Main3 {
	
	public static int[] merge(int[] nums1, int m, int[] nums2, int n) {
        int[] newarr=new int[m+n];
        int i = 0, j = 0, k = 0;
        
        // Traverse both arrays
        while (i < m && j < n) {
            if (nums1[i] <= nums2[j]) {
                newarr[k++] = nums1[i++];
            } else {
                newarr[k++] = nums2[j++];
            }
        }
        
        // Store remaining elements of arr1
        while (i < m) {
            newarr[k++] = nums1[i++];
        }
        
        // Store remaining elements of arr2
        while (j < n) {
            newarr[k++] = nums2[j++];
        }
        return newarr;
    }
	public static void main(String[] args) {
		int[] arr1 = {1,2,3,0,0,0};
        int[] arr2 = {2,5,6};
        
        int[] mergedArray = merge(arr1,3, arr2,3);
        
        System.out.println("Merged Array: ");
        for (int num : mergedArray) {
            System.out.print(num + " ");
        }
	}
}
