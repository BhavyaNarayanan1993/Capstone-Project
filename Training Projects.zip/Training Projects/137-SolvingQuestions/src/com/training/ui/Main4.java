package com.training.ui;

public class Main4 {
	public static void main(String[] args) {
		String Str="$123 I# am56 Java Developer%9";
		int x=calculateSum(Str);
		System.out.println(x);
	}
	public static int calculateSum(String str) {
		int val;
		val=str.chars().filter(Character::isDigit).map(c->c-'0').sum();
		//String[] str1=str.split("$");
		
		return val;
		//return 0;
	}
}
