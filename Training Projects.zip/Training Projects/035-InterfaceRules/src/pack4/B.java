package pack4;

public class B implements A{

}
