package com.order.dto.response;

import com.order.model.Order;

public class OrderAddResponse {
	int statusCode;
	String description;
	Order order;
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Order getOrder() {
		return order;
	}
	public void setOrder(Order order) {
		this.order = order;
	}
	@Override
	public String toString() {
		return "OrderAddResponse [statusCode=" + statusCode + ", description=" + description + ", order=" + order + "]";
	}
	
	
	
}
