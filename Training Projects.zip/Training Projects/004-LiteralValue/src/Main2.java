
public class Main2 {

	public static void main(String[] args) {
		System.out.println(10.00);//double type literal
		System.out.println(10.00f);//float type literal
		System.out.println(1.1E2);//double type literal using scientific notation 10 to the power 30
		System.out.println(3.4E-2);// 3.4 * 10 power -2  double 
	}

}
