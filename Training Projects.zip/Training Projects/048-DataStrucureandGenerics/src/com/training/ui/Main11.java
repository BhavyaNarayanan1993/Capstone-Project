package com.training.ui;

import com.training.ds.Stack;
import com.training.ds.StackImpl;
import com.training.model.Account;

public class Main11 {

	public static void main(String[] args) {
		try{
		Stack<Account> stack=new StackImpl<>(15);
		
		stack.push(new Account("Manu",20000.00));
		stack.push(new Account("Ram", 44000.00));
		stack.push(new Account("Hari", 25000.00));
		stack.push(new Account("Reena",35000.00));
		stack.push(new Account("Meena",25000.00));
		
		System.out.println(stack);
		
		Account a=stack.pop();
		System.out.println(a);
		System.out.println(stack);
		System.out.println(a.getCustomerName()+","+a.getBalance());
		
		a=stack.pop();
		System.out.println(a);
		System.out.println(stack);
		System.out.println(a.getCustomerName()+","+a.getBalance());
		
		a=stack.pop();
		System.out.println(a);
		System.out.println(stack);
		System.out.println(a.getCustomerName()+","+a.getBalance());
		}catch(Throwable e ) {
			System.err.println(e.getMessage());
		}
	}

}
