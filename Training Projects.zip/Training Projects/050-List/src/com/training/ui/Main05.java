package com.training.ui;

import java.util.LinkedList;
import java.util.List;

public class Main05 {

	public static void main(String[] args) {
		int sum=0;
		List<Integer> list=new LinkedList<>();
		
		list.add(Integer.valueOf(200));
		list.add(Integer.valueOf(300));
		list.add(Integer.valueOf(400));
		list.add(Integer.valueOf(500));
		list.add(Integer.valueOf(600));
		list.add(1500);
		list.add(1800);
		
		for(Integer i:list) {
			System.out.println(i);
			sum=sum+i;
		}
		System.out.println("Sum="+sum);
	}

}
