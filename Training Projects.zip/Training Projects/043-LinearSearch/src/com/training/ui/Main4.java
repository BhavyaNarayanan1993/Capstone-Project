package com.training.ui;

import com.training.model.Square;

public class Main4 {
	
	private static int search(Square[] arr, Square searchObject) {
		
		for(int i=0;i<arr.length;i++) {
			if(arr[i].equals(searchObject))
				return i;
		}
		return -1;
	}

	public static void main(String[] args) {
		Square[] squares=new Square[5];
		
		Square sq1=new Square(34);
		Square sq2=new Square(15);
		squares[0]=sq1;
		squares[1]=sq2;
		squares[2]=new Square(16);
		squares[3]=new Square(27);
		squares[4]=new Square(97);
		
		Square searchObject=new Square(97);
		
		int searchResult=search(squares, searchObject);
		if(searchResult==-1) 
			System.out.println("Search Data not found");
		else
			System.out.println("Search element "+searchObject+" found in position:"+searchResult); 

	}

}
