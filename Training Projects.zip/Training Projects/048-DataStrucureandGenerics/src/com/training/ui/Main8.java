package com.training.ui;

import com.training.ds.ObjectStack;
import com.training.model.Account;
import com.training.model.BillItem;
import com.training.model.Circle;
import com.training.model.Employee;
import com.training.model.Manager;
import com.training.model.Person;
import com.training.model.SalesEmployee;
import com.training.model.Square;

public class Main8 {

	public static void main(String[] args) {
		Integer obj1=Integer.valueOf(24);
		String obj2=new String("Welcome");
		Circle obj3=new Circle(14);
		Square obj4=new Square(100);
		BillItem obj5=new BillItem("Iphone", 10, 50000.00);
		Employee obj6=new Employee(101,"Raju","MALE","Mumbai",2000.00);
		Manager obj7=new Manager(102, "Manu", "MALE", "Pune", 3000.00, 10);
		SalesEmployee obj8=new SalesEmployee(103, "Sheena", "FEMALE", "Kochi", 2500.00, 3000.00);
		Account obj9=new Account("Surya", 89000.00);
		Person obj10=new Person("Kavya", 25);
		
		ObjectStack stack=new ObjectStack(20);
		stack.push(obj1);
		stack.push(obj2);
		stack.push(obj3);
		stack.push(obj4);
		stack.push(obj5);
		stack.push(obj6);
		stack.push(obj7);
		stack.push(obj8);
		stack.push(obj9);
		stack.push(obj10);
		
		System.out.println(stack);
		
		Object r=stack.pop();
		System.out.println(r);
		
		if(r instanceof Person) {
			Person p=(Person)r;
			System.out.println(p.getName()+","+p.getAge());
			System.out.println(stack);
		}
		if(r instanceof Integer) {
			Integer temp=(Integer)r;
			System.out.println(temp.intValue());
			System.out.println(stack);
			}
		if(r instanceof String) {
			String temp=(String)r;
			System.out.println(temp.toUpperCase());
			System.out.println(stack);
			}
		if(r instanceof Circle) {
			Circle temp=(Circle)r;
			System.out.println(temp.getArea());
			System.out.println(stack);
			}
		if(r instanceof Square) {
			Square temp=(Square)r;
			System.out.println(temp.getArea());
			System.out.println(stack);
			}
		if(r instanceof Square) {
			Square temp=(Square)r;
			System.out.println(temp.getArea());
			System.out.println(stack);
			}
		if(r instanceof BillItem) {
			BillItem temp=(BillItem)r;
			System.out.println(temp.getItemName()+","+temp.getItemValue()+","+temp.getPrice()+","+temp.getQuantity());
			System.out.println(stack);
			}
		if(r instanceof Employee) {
			Employee temp=(Employee)r;
			System.out.println(temp.getId()+","+temp.getName()+","+temp.getGender()+","+temp.getBasic()+","+temp.getCityName()+","+temp.getNetSalary());
			System.out.println(stack);
			}
		if(r instanceof Manager) {
			Manager temp=(Manager)r;
			System.out.println(temp.getEmployeeCount());
			System.out.println(stack);
			}
		if(r instanceof SalesEmployee) {
			SalesEmployee temp=(SalesEmployee)r;
			System.out.println(temp.getSalesAmount());
			System.out.println(stack);
			}
		if(r instanceof Account) {
			Account temp=(Account)r;
			System.out.println(temp.getCustomerName()+","+temp.getBalance());
			System.out.println(stack);
			}
	}

}
