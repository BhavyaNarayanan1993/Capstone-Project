package pack1;

public class Circle implements Shape{
		private int radius;

		public Circle(int radius) {
			super();
			this.radius = radius;
		}
		
		public Circle() {
			super();
		}

		public int getRadius() {
			return radius;
		}

		public void setRadius(int radius) {
			this.radius = radius;
		}
		
		public double calculateArea() {
			return 3.14*this.radius*this.radius;
		}

		@Override
		public String toString() {
			return "Circle [getRadius()=" + getRadius() + ", calculateArea()=" + calculateArea() + "]";
		}

		@Override
		public void setSize(int size) {
			
			setRadius(size);
		}

		@Override
		public int getSize() {
			return getRadius();
		}

		@Override
		public double getArea() {
			return calculateArea();
		}
		
		
}
