package com.training.ui;

import com.training.model.Person;

public class Main3 {

	public static void main(String[] args) {
		Person per1=new Person("Ram", 50);
		Person per2=new Person("Raj", 60);
		
		int a=per1.compareTo(per2);
		System.out.println(a);
		
		if(a>0)
			System.out.println("Person1 is elder than Person2");
		if(a<0)
			System.out.println("Person1 is younger than Person2");
		if(a==0)
			System.out.println("Person1 is same age as Person2");

	}

}
