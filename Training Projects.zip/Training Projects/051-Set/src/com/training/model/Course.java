package com.training.model;

import java.util.HashSet;
import java.util.Set;

public class Course{
	
		private String courseName;
		private Set<CourseItem> courseItems;
		
		public Course(String courseName) {
			super();
			this.courseName = courseName;
			this.courseItems = new HashSet<>();
		}
		
		public void addCourseItem(String subjectName, int duration,double fees) {
			CourseItem courseItem=new CourseItem(subjectName,duration,fees);
			this.courseItems.add(courseItem);
			
		}
		
		public void printCourseDetails() {
			System.out.println("---------------------------------------------------------------");
			System.out.println("Course Name: "+ this.courseName);
			System.out.println("---------------------------------------------------------------");
			System.out.println("SlNo\tSubject Name\t\tDuration\tFees");
			System.out.println("---------------------------------------------------------------");
			
			int slno=1;
			double totalFees=0.0;
			for(CourseItem c:this.courseItems) {
				System.out.println(slno+"\t"+c.getSubjectName()+"\t\t\t"+c.getDurationInHours()+"\t\t"+c.getFees());
				slno++;
				totalFees=totalFees+c.getFees();
			}
			System.out.println("---------------------------------------------------------------");
			System.out.println("Total Fees: "+totalFees);
			System.out.println("---------------------------------------------------------------");
		}
}
