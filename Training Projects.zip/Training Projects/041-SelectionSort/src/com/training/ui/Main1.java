package com.training.ui;

import java.util.Arrays;

public class Main1 {

	public static void main(String[] args) {
		//selection sort
		int[] arr= {12,19,55,2,16};
		int n=arr.length;
		
		int imin;
		for(int i=0;i<n-1;i++) {
			imin=i;
			for(int j=i+1;j<n;j++) {
				//System.out.println("i="+i+" j="+j);
				//System.out.println("imin="+imin+" j="+j+" arr[imin]="+arr[imin]+" arr[j]="+arr[j]);
				if(arr[j]<arr[imin]) {
					imin=j;
					//System.out.println("imin="+imin+" j="+j+" arr[imin]="+arr[imin]+" arr[j]="+arr[j]);
				}
			}
			int temp;
			temp=arr[i];
			arr[i]=arr[imin];
			arr[imin]=temp;
			//System.out.println(Arrays.toString(arr));
		}
		System.out.println(Arrays.toString(arr));

	}

}
