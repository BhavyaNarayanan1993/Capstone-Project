package com.training.model;

import java.util.LinkedList;
import java.util.List;

public class LibraryManagement {
		List<Book> allBooks;

		public LibraryManagement() {
			super();
			this.allBooks = new LinkedList<Book>();
			//create 10 objects
			Book book1=new Book("Harry Potter", "J K Rowling", 500, false);
			Book book2=new Book("Notebook", "Sparks", 700, false);
			Book book3=new Book("A Christmas Carol", "Charles Dickens", 560, false);
			Book book4=new Book("Oliver Twist", "Charles Dickens", 800, false);
			Book book5=new Book("Great Expectation", "Charles Dickens", 400, false);
			Book book6=new Book("Romeo Juliet", "Shakespeare", 1000, false);
			Book book7=new Book("Ceaser", "Shakespeare", 900, false);
			Book book8=new Book("Harry Potter2", "J K Rowling", 600, false);
			Book book9=new Book("Harry Potter3", "J K Rowling", 660, false);
			Book book10=new Book("Harry Potter4", "J K Rowling", 700, false);
			//add all the books to allBooks
			allBooks.add(book1);
			allBooks.add(book2);
			allBooks.add(book3);
			allBooks.add(book4);
			allBooks.add(book5);
			allBooks.add(book6);
			allBooks.add(book7);
			allBooks.add(book8);
			allBooks.add(book9);
			allBooks.add(book10);
		}
		
		public void issueBook(String bookName) {
			//find the book which is issued and change the status as true
			for (Book book : allBooks) {
				if(book.getBookName().equals(bookName)) {
					book.setIssueStatus(true);
					System.out.println(book);
				}
			}
		}
		
		public void printAvailableBooks() {
			//	print all the books false
			for (Book book : allBooks) {
				if(!book.isIssueStatus())
				{
					System.out.println(book);
				}
			}
		}
		
		public int getAvailableBooksCount() {
			//return counts of available books
			int availCount=(int) allBooks.stream().filter(c->c.isIssueStatus()==false).count();		
			return availCount;
		}
		public int getIssuedBookCount() {
			int issueCount=(int) allBooks.stream().filter(c->c.isIssueStatus()==true).count();
			return issueCount;
		}
		
}
