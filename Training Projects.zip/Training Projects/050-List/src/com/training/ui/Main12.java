package com.training.ui;

import com.training.model.Department;

public class Main12 {

	public static void main(String[] args) {
		Department department=new Department("IT", "Manu");
		department.addEmployee(101, "Deepa", "Female", "Mumbai", 1000.00);
		department.addEmployee(104, "Sree", "Female", "Kochi", 2000.00);
		department.addEmployee(103, "Kiran", "Male", "Pune", 3000.00);
		department.addEmployee(102, "Naina", "Female", "Mysore", 4000.00);
		department.addEmployee(105, "Meena", "Female", "Pune", 5000.00);
		
	
		//System.out.println(department.isEmployeePresent(102));
		//System.out.println(department.findByEmployeeId(106));
		department.printReport();
		
		department.updateEmployee(103, "Sree", "Male", "Cochin", 5000.00);
		department.printReport();
		department.deleteEmployee(103);
		department.printReport();
	}

}
