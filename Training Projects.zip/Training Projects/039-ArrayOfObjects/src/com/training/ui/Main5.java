package com.training.ui;

import com.training.model.BillItem;
import com.training.model.Circle;
import com.training.model.Employee;
import com.training.model.Manager;
import com.training.model.SalesEmployee;
import com.training.model.Square;

public class Main5 {

	public static void main(String[] args) {
		Object[] arr=new Object[6];
		
		Circle c=new Circle(10);
		Square s=new Square(20);
		BillItem b=new  BillItem("Redmi",2,44000.00);
		Employee employee=new Employee(104, "Menaka", "FEMALE", "Cochin", 1000.00);
		Manager manager=new Manager(101, "Ram", "MALE", "Mumbai", 1000.00, 12);
		SalesEmployee salesEmployee=new SalesEmployee(102, "Dinesh", "MALE", "Delhi", 1000.00, 100000.00);

		arr[0]=c;
		arr[1]=s;
		arr[2]=b;
		arr[3]=employee;
		arr[4]=manager;
		arr[5]=salesEmployee;
		
		for(Object obj:arr) {
			System.out.println(obj.toString());
			
			if(obj instanceof Circle) {
				Circle temp=(Circle)obj;
				System.out.println("Radius:"+ temp.getRadius());
			}
			
			if(obj instanceof Square) {
				Square temp=(Square)obj;
				System.out.println("Size:"+ temp.getSize());
			}
			
			if(obj instanceof BillItem) {
				BillItem temp=(BillItem)obj;
				System.out.println("Item Value:"+ temp.getItemValue());
			}
			
			if(obj instanceof Employee) {
				Employee temp=(Employee)obj;
				System.out.println("Employee ID:"+temp.getId());
				System.out.println("Emp Name: "+temp.getName());
				System.out.println("Emp Gender: "+temp.getGender());
				System.out.println("Emp CityName:"+temp.getCityName());
				System.out.println("Emp Basic: "+temp.getBasic());
				System.out.println("Net Salary: "+temp.getNetSalary());
			}
			
			if(obj instanceof Manager) {
				Manager temp=(Manager)obj;
				System.out.println("Employee Count: "+temp.getEmployeeCount());
			}
			
			if(obj instanceof SalesEmployee) {
				SalesEmployee temp=(SalesEmployee)obj;
				System.out.println("Sales Amount : "+temp.getSalesAmount());
			}
			
		}
	}

}
