package com.order.dto.request;

import com.order.bill.dto.BillDTO;

public class GenerateBillRequest {
	BillDTO billDTO;

	public BillDTO getBillDTO() {
		return billDTO;
	}

	public void setBillDTO(BillDTO billDTO) {
		this.billDTO = billDTO;
	}
	
	
}
