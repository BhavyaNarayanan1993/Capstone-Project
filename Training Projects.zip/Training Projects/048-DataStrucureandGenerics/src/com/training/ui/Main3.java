package com.training.ui;

import com.training.ds.DoubleStack;

public class Main3 {

	public static void main(String[] args) {
		byte v1=30;
		short v2=40;
		int v3=80;
		long v4=90;
		char v5='A';
		float v6=78.0f;
		double v7=800.05;
		
		DoubleStack stack=new DoubleStack(10);
		stack.push(v1);
		stack.push(v2);
		stack.push(v3);
		stack.push(v4);
		stack.push(v5);
		stack.push(v6);
		stack.push(v7);
		
		System.out.println(stack);
		
		double r=stack.pop();
		System.out.println(r);
		System.out.println(stack);
		
		r=stack.pop();
		System.out.println(r);
		System.out.println(stack);
		
		r=stack.pop();
		System.out.println(r);
		System.out.println(stack);
	}

}
