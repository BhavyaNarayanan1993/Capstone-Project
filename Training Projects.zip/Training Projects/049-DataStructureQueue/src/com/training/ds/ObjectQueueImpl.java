package com.training.ds;

import com.training.model.Employee;

public class ObjectQueueImpl implements Queue<Employee>{

	@Override
	public void enQueue(Employee Object) throws Throwable {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Employee deQueue() throws Throwable {
		// TODO Auto-generated method stub
		return null;
	}

}
