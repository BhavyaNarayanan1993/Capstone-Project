package pack2;

import pack1.Circle;
import pack1.Square;

public class Main2 {
	public static void main(String[] args) {
		Square s=new Square();
		s.setSize(10);
		System.out.println(s.getSize());
		System.out.println(s.computeArea());
		
		Circle c=new Circle();
		c.setRadius(10);
		System.out.println(c.getRadius());
		System.out.println(c.calculateArea());

	}
				
}
