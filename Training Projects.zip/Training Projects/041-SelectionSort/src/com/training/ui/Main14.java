package com.training.ui;

import java.util.Arrays;

import com.training.model.Person;
import com.training.model.comparators.PersonNameComparator;

public class Main14 {

	public static void main(String[] args) {
		Person person1=new Person("Ram",35);
		Person person2=new Person("Veena",44);
		Person person3=new Person("Raj",18);
		Person person4=new Person("Pooja",22);
		
		Person[] persons= {person1,person2,person3,person4};
		
		int n = persons.length;

		int imin;
		for (int i = 0; i < n - 1; i++) {
			imin = i;
			for (int j = i + 1; j < n; j++) {
				PersonNameComparator comparator=new PersonNameComparator();
				int r=comparator.compare(persons[j], persons[imin]);
				if(r<0)
					imin = j;
					
			}
			Person temp;
			temp = persons[i];
			persons[i] = persons[imin];
			persons[imin] = temp;

		}
		System.out.println(Arrays.toString(persons));

	}

}
