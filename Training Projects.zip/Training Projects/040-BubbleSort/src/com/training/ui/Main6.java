package com.training.ui;

import java.util.Arrays;

import com.training.model.BillItem;
import com.training.model.comparators.BillItemPriceComparator;

public class Main6 {

	public static void main(String[] args) {
		BillItem b1=new  BillItem("Redmi",2,44000.00);

		BillItem[] billItems= {	new  BillItem("Samsung",2,15000.00),
								new  BillItem("Nokia",3,12000.00),
								new  BillItem("Oppo",2,32000.00),
								b1
								};
		
		for(int i=0;i<billItems.length;i++) {
			for (int j=0;j<billItems.length-i-1;j++) {
				
				BillItemPriceComparator comparator=new BillItemPriceComparator();
				int r=comparator.compare(billItems[j], billItems[j+1]);
				if(r>0)
				{
					BillItem temp;
					temp=billItems[j];
					billItems[j]=billItems[j+1];
					billItems[j+1]=temp;
				}
				
			}
		}
		System.out.println(Arrays.toString(billItems));

	}

}
