package pack1;

public class SchoolStudent implements Student{

	@Override
	public void enroll() {
		System.out.println("School Student enroll");
		
	}

	@Override
	public void takeExam() {
		System.out.println("School Student takeExam");
		
	}

	@Override
	public void leave() {
		System.out.println("School Student leave");
		
	}

}
