package com.training.ui;

import java.util.Arrays;

import com.training.model.Person;
import com.training.model.comparators.PersonNameComparator;

public class Main14 {

	public static void main(String[] args) {
		Person person1=new Person("Ram",35);
		Person person2=new Person("Arun",44);
		Person person3=new Person("Sana",18);
		Person person4=new Person("Pooja",22);
		
		Person[] persons= {person1,person2,person3,person4};
		
		int n = persons.length;
		
		for(int i=1;i<n;++i) {
			Person key=persons[i];
			int j=i-1;
			PersonNameComparator comparator=new PersonNameComparator();
			int r=comparator.compare(persons[j], key);
			while(j>=0 && r>0) {
				persons[j+1]=persons[j];
				j=j-1;
				if(j>=0)
					r=comparator.compare(persons[j], key);
				
			}
			persons[j+1]=key;
		}
		System.out.println(Arrays.toString(persons));

	}

}
