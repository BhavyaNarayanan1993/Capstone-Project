package pack2;

import pack1.CollegeStudent;
import pack1.SchoolStudent;
import pack1.Student;
import pack1.UniversityStudent;

public class Main1 {

	public static void main(String[] args) {
		Student stud;
		
		stud=new SchoolStudent();
		stud.enroll();
		stud.takeExam();
		stud.leave();
		System.out.println("-----------------");
		
		stud=new CollegeStudent();
		stud.enroll();
		stud.takeExam();
		stud.leave();
		System.out.println("-----------------");
		
		stud=new UniversityStudent();
		stud.enroll();
		stud.takeExam();
		stud.leave();

	}

}
