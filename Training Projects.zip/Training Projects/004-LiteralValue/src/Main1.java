
public class Main1 {

	public static void main(String[] args) {
		System.out.println(1234);	//int literal (decimal)
		System.out.println(04412);	//int literal (octal)
		System.out.println(0x125f);	//int literal (hexa)
		System.out.println(0b1100);	//int literal (binary)
	}

}
