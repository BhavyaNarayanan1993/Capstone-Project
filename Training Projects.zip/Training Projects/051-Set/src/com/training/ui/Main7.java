package com.training.ui;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class Main7 {

	public static void main(String[] args) {
		Set<String> set=new TreeSet<>();
		
		set.add("Delhi");
		set.add("Mumbai");
		set.add("Kolkata");
		set.add("Pune");
		set.add("Bangalore");
		set.add("Delhi");
		System.out.println(set);
		
		System.out.println(set.contains("Mumbai"));
		set.remove("Pune");
		
		Iterator<String> it=set.iterator();
		while(it.hasNext()) {
			String s=it.next();
			System.out.println(s.toUpperCase());
			System.out.println(s.length());
		}
		
		set.clear();
		System.out.println(set.isEmpty());
		System.out.println(set.size());
	}

}
