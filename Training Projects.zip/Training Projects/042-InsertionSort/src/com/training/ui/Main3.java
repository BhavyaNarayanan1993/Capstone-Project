package com.training.ui;

import java.util.Arrays;

import com.training.model.Circle;

public class Main3 {

	public static void main(String[] args) {
		Circle[] circles=new  Circle[4];
		Circle c1=new Circle(10);
		Circle c2=new Circle(5);
		Circle c3=new Circle(15);
		
		circles[0]=c1;
		circles[1]=c2;
		circles[2]=c3;
		circles[3]=new Circle(30);
		
		int n=circles.length;
		for(int i=1;i<n;i++) {
			Circle key=circles[i];
			int j=i-1;
			
			int r=circles[j].compareTo(key);
			while(j>=0 && r>0) {
				circles[j+1]=circles[j];
				j=j-1;
				if(j>=0)
					r=circles[j].compareTo(key);
			}
			circles[j+1]=key;
		}
		System.out.println(Arrays.toString(circles));

	}

}
