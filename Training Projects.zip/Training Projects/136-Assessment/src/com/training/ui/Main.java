package com.training.ui;

import java.util.Scanner;

public class Main {
 
	public static void main(String[] args) {
		Movie movies = new Movie();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter no of queries: ");
		int q = sc.nextInt();
		if (q < 1 || q > 5000)
			throw new IllegalArgumentException("Invalid no.od quries");
		while (q > 0) {
			System.out.println("Enter operation name:");
			String op = sc.next();
			if (op.equals("BOOK")) {
				System.out.println("Enter customer id");
				int x = sc.nextInt();
				System.out.println("Enter movie id");
				int y = sc.nextInt();
				System.out.println(movies.book(x, y) ? "Booked" : "Couldn't booked");
			} else if (op.equals("CANCEL")) {
				System.out.println("Enter customer id");
				int x = sc.nextInt();
				System.out.println("Enter movie id");
				int y = sc.nextInt();
				System.out.println(movies.cancel(x, y) ? "canceled" : "Couldn't cancel");
			} else if (op.equals("ISBOOKED")) {
				System.out.println("Enter customer id");
				int x = sc.nextInt();
				System.out.println("Enter movie id");
				int y = sc.nextInt();
				System.out.println(movies.isBooked(x, y) ? "Booked" : "Not booked");
			} else if (op.equals("AVAILABLE_TICKETS")) {
				System.out.println("Enter movie id");
				int x = sc.nextInt();
				System.out.println(" Available tickets " + movies.availableTickets(x));
			} else {
				throw new IllegalArgumentException("Invalid operation");
			}
			q--;
		}
		sc.close();
	}
}