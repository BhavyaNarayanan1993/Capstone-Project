package com.training.ui;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.training.model.Employee;
import com.training.model.LeaveApplication;
import com.training.model.Manager;

public class Main {
	static List<Employee> empList = new ArrayList<Employee>();
	static List<Manager> managerList = new ArrayList<Manager>();
	public static List<LeaveApplication> leaveList = new ArrayList<LeaveApplication>();
	static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		String role;
		String loginName;
		int exit;
		init();
		while (true) {
			System.out.println("Are you manager or Employee: ");
			role = scanner.next();
			System.out.println("Enter your Name: ");
			loginName = scanner.next();
			System.out.println("Enter 0 to exit");
			exit = scanner.nextInt();

			// if role is employee take input for leave application
			// if the role is manger we should display all the leave application submitted
			// to this manager;
			// Manager will see the list the will either approve or reject the leave
			// When an employee is already have a history of leave it should be displayed
			// before the new leave apply
			if (exit != 0) {
				if (role.equalsIgnoreCase("Employee")) {
					applyLeave(loginName);
				}
				if (role.equalsIgnoreCase("Manager")) {
					displayLeaveApplication(loginName);
				}
			}
		}
	}

	public static void init() {

		Employee emp1 = new Employee(1, "Manu");
		Employee emp2 = new Employee(2, "Arun");
		Employee emp3 = new Employee(3, "Meenu");
		Employee emp4 = new Employee(4, "Rahul");
		Employee emp5 = new Employee(5, "Kiran");
		Employee emp6 = new Employee(6, "Jithu");
		Employee emp7 = new Employee(7, "Nithu");
		Employee emp8 = new Employee(8, "Harry");
		Employee emp9 = new Employee(9, "Suresh");
		Employee emp10 = new Employee(10, "Ramesh");

		empList.add(emp1);
		empList.add(emp2);
		empList.add(emp3);
		empList.add(emp4);
		empList.add(emp5);
		empList.add(emp6);
		empList.add(emp7);
		empList.add(emp8);
		empList.add(emp9);
		empList.add(emp10);

		Manager manager1 = new Manager(100, "Raj", "Sales");
		Manager manager2 = new Manager(101, "Simran", "HR");
		Manager manager3 = new Manager(102, "Manoj", "Security");

		managerList.add(manager1);
		managerList.add(manager2);
		managerList.add(manager3);
	}

	public static void applyLeave(String loginName) {
		System.out.println(empList);

		for (Employee employee : empList) {
			if (employee.getName().equals(loginName)) {
				System.out.println("Enter your Employee ID : ");
				int empId = scanner.nextInt();

				System.out.println("Enter your Manager ID : ");
				int mgrId = scanner.nextInt();

				System.out.println("Enter your FROM Date of Leave : ");
				LocalDate fromDate = LocalDate.parse(scanner.next());

				System.out.println("Enter your TO Date of Leave : ");
				LocalDate toDate = LocalDate.parse(scanner.next());

				System.out.println("Enter your Leave Reason : ");
				String reason = scanner.next();

				LeaveApplication leaveApp = new LeaveApplication();
				leaveApp.setEmpId(empId);
				leaveApp.setManagerId(mgrId);
				leaveApp.setFromDate(fromDate);
				leaveApp.setToDate(toDate);
				leaveApp.setReason(reason);

				leaveList.add(leaveApp);
				System.out.println(leaveList);
				System.out.println("Applied Leave Successful");
			}
		}
	}

	private static void displayLeaveApplication(String loginName) {
		int id;
		System.out.println("Enter Manager ID");
		id = scanner.nextInt();
		System.out.println(managerList);

		for (LeaveApplication leave : leaveList) {
			if (leave.getManagerId() == id) {
				System.out.println(leave);
				leave.setApprovedOrRejected("Approved");
			} else {
				System.out.println("No active leave request");
			}
		}

		for (LeaveApplication leave : leaveList) {
			if (leave.getApprovedOrRejected() == "null") {
				leave.setApprovedOrRejected("Approved");
				System.out.println("Leave Approved");
			} else {
				leave.setApprovedOrRejected("Rejected");
				System.out.println("Leave Rejected");
			}
		}

	}
}
