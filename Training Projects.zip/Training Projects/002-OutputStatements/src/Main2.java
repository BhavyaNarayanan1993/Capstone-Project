
public class Main2 {

	public static void main(String[] args) {
		int age=30;
		String name="Bhavya" ;
		System.out.println("My name is "+name+" My age is " +age);

	}

}
