package pack2;

public interface B extends A{
		void test2();
}
