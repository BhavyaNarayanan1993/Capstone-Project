package com.training.ui;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import com.training.model.Account;
import com.training.model.BillItem;
import com.training.model.comparators.BillItemPriceComparator;

public class Main5 {

	public static void main(String[] args) {
		Set<BillItem> billItemSet=new HashSet<>();
		billItemSet.add(new BillItem("Iphone", 3, 60000.00));
		billItemSet.add(new BillItem("Redmi", 4, 80000.00));
		billItemSet.add(new BillItem("Samsung", 5, 30000.00));
		billItemSet.add(new BillItem("Oppo", 1, 70000.00));
		billItemSet.add(new BillItem("Redmi", 8, 40000.00));
		
		System.out.println(billItemSet.size());
		System.out.println(billItemSet);
		
		BillItem searchbillItem=new BillItem("Oppo", 2, 23000.00);
		
		System.out.println(billItemSet.contains(searchbillItem));
		
		billItemSet.remove(new BillItem("Redmi", 5, 20000.00));
		System.out.println(billItemSet);
		//iterate over set element
		//calculate the total of itemvalue and print it
		
		double total=0.0;
		Iterator<BillItem> it=billItemSet.iterator();
		while(it.hasNext()) {
			BillItem bill=it.next();
			total=total+bill.getItemValue();
		}
		System.out.println("Total="+total);
		
		BillItemPriceComparator comparator=new BillItemPriceComparator();
		BillItem lowestPricedBillItem=new BillItem("Iphone", 6, 20000.00);
		for(BillItem b:billItemSet) {
			int r=comparator.compare(b, lowestPricedBillItem);
			if(r<0)
				lowestPricedBillItem=b;
		}
		System.out.println(lowestPricedBillItem);

		billItemSet.clear();
		System.out.println(billItemSet.isEmpty());
		System.out.println(billItemSet.size());
		//clear the set
		//print isempty
	}

}
