package com.training.model.comparators;

import java.util.Comparator;

import com.training.model.Person;

public class PersonNameComparator implements Comparator{

	@Override
	public int compare(Object o1, Object o2) {
		Person per1=(Person)o1;
		Person per2=(Person)o2;
		
		int r=per1.getName().compareTo(per2.getName());
		return r;
	}

}
