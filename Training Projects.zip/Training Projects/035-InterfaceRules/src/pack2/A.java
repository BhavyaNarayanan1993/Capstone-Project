package pack2;

public interface A {
		void test1();
		
}
