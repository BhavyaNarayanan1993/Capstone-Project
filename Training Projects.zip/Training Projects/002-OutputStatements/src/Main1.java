
public class Main1 {

	public static void main(String[] args) {
		System.out.println("Hello");
		System.out.print("World");
		System.out.println("UST");
	}

}
