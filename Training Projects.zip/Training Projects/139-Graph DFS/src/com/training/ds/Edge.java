package com.training.ds;

public class Edge {
		int source,dest;

		public Edge(int source, int dest) {
			super();
			this.source = source;
			this.dest = dest;
		}
		
}
