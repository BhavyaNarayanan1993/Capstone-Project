
package com.training.ui;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
 
class Movie {
	private static final int MAX_TIC = 100;
	private Map<Integer, Set<Integer>> customerBookings;
	private Map<Integer, Integer> availableTickets;
 
	public Movie() {
		customerBookings = new HashMap<Integer, Set<Integer>>();
		availableTickets = new HashMap<Integer, Integer>();
	}
 
	public boolean book(int cust_id, int movie_id) {
		if (!availableTickets.containsKey(movie_id)) {
			availableTickets.put(movie_id, MAX_TIC);
		}
		if (customerBookings.containsKey(cust_id) && customerBookings.get(cust_id).contains(movie_id)) {
			return false;
		}
		if (availableTickets.get(movie_id) <= 0) {
			return false;
		}
 
		customerBookings.putIfAbsent(cust_id, new HashSet<>());
		customerBookings.get(cust_id).add(movie_id);
		availableTickets.put(movie_id, availableTickets.get(movie_id) - 1);
 
		return true;
	}
 
	public boolean cancel(int cust_id, int movie_id) {
 
		if (!customerBookings.containsKey(cust_id) || !customerBookings.get(cust_id).contains(movie_id)) {
			return false;
		}
 
		customerBookings.get(cust_id).remove(movie_id);
		if (customerBookings.get(cust_id).isEmpty()) {
			customerBookings.remove(cust_id);
		}
 
		availableTickets.put(movie_id, availableTickets.get(movie_id) + 1);
 
		return true;
	}
 
	public boolean isBooked(int cust_id, int movie_id) {
		return customerBookings.containsKey(cust_id) && customerBookings.get(cust_id).contains(movie_id);
	}
 
	public int availableTickets(int movie_id) {
		return availableTickets.getOrDefault(movie_id, MAX_TIC);
	}
 
}
 
