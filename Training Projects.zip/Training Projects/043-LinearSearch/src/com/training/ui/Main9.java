package com.training.ui;

import java.util.Comparator;

import com.training.model.Person;
import com.training.model.comparators.PersonNameComparator;

public class Main9 {
	
	private static int search(Person[] arr, Person searchObject) {
		
		for (int i = 0; i < arr.length; i++) {
			if (searchObject instanceof Comparable) {
				Comparable searchData = searchObject;
				int r = arr[i].compareTo(searchData);
				if (r == 0)
					return i;
			}
		}
		return -1;
	}
	
	private static int nameSearch(Person[] arr, Person searchObject) {
		Comparator comparator = new PersonNameComparator();
		for (int i = 0; i < arr.length; i++) {
			int r = comparator.compare(arr[i], searchObject);
			if (r == 0)
				return i;
		}
		return -1;
	}

	public static void main(String[] args) {
		Person person1=new Person("Ram",35);
		Person person2=new Person("Sana",44);
		Person person3=new Person("Raj",18);
		Person person4=new Person("Pooja",22);
		
		Person[] persons= {person1,person2,person3,person4};
		
		Person searchObject=new Person("Sana", 33);
		
		System.out.println("------Age Search with Comparable --------");
		int searchResult=search(persons, searchObject);
		if (searchResult == -1)
			System.out.println("Search Data not found");
		else
			System.out.println("Search element " + searchObject + " found in position:" + searchResult);

		
		System.out.println("------Name Search with Comparator--------");
		int nSearchResult = nameSearch(persons, searchObject);
		if (nSearchResult == -1)
			System.out.println("Search Data not found");
		else
			System.out.println("Search element " + searchObject + " found in position:" + nSearchResult);

	}

}
