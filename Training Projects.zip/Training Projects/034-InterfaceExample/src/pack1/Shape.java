package pack1;

public interface Shape {
		
		double PI=3.14;
		void setSize(int size);
		int getSize();
		double getArea();
}
