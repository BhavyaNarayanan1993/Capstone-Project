package com.training.ds;

public interface Queue<T> {
	
		void enQueue(T Object) throws Throwable;
		T deQueue() throws Throwable;

}
