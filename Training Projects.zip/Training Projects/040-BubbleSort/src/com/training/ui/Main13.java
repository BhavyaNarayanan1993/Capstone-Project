package com.training.ui;

import java.util.Arrays;

import com.training.model.Person;

public class Main13 {

	public static void main(String[] args) {
		Person person1=new Person("Ram",50);
		Person person2=new Person("Sana",40);
		Person person3=new Person("Raj",30);
		Person person4=new Person("Pooja",22);
		
		Person[] persons= {person1,person2,person3,person4};
		
		for(int i=0;i<persons.length;i++) {
			for (int j=0;j<persons.length-i-1;j++) {
				int r=persons[j].compareTo(persons[j+1]);
				if(r>0)
				{
					Person temp;
					temp=persons[j];
					persons[j]=persons[j+1];
					persons[j+1]=temp;
				}
				
			}
		}
		System.out.println(Arrays.toString(persons));
		
	}

}
