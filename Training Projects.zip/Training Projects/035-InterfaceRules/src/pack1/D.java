package pack1;

public class D {
	public void doSomething() {
		
	}
}
