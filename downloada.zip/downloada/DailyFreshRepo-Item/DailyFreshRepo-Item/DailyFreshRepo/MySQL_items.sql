show databases;

create database dailyfreshdb1;

use dailyfreshdb1;

show tables;

select * from items;

desc contacts;
desc suppliers;