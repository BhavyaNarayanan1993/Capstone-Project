package com.training.ui;

import java.util.PriorityQueue;

public class Main3 {

	public static void main(String[] args) {
		PriorityQueue<String> names;
		names =new PriorityQueue<String>();
		
		names.add("Jithin");
		names.add("Agneya");
		names.add("Hari");
		names.add("Karthik");
		
		for(int i=0;i<2;i++) {
		System.out.println(names.poll());
		}
	}

}
