package com.training.ui;

import java.util.Map;
import java.util.TreeMap;

import com.training.model.Circle;

public class Main4 {

	public static void main(String[] args) {
		Map<Circle,String> circles=new TreeMap<>();
		
		Circle c1=new Circle(100);
		Circle c2=new Circle(50);
		Circle c3=new Circle(5);
		
		circles.put(c1, "Largest");
		circles.put(c2, "Medium");
		circles.put(c3, "Smallest");
		
		System.out.println(circles);
		
		for(Map.Entry<Circle, String> entry:circles.entrySet()){
			System.out.println(entry.getKey()+"-"+entry.getValue());
		}

	}

}
