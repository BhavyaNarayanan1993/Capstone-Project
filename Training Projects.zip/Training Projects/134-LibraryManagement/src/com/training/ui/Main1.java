package com.training.ui;

import com.training.model.LibraryManagement;

public class Main1 {

	public static void main(String[] args) {
		LibraryManagement management=new LibraryManagement();
		management.issueBook("Oliver Twist");
		management.issueBook("Harry Potter");
		management.issueBook("Harry Potter2");
		System.out.println("-------------------------------------------------");
		management.printAvailableBooks();
		System.out.println("-------------------------------------------------");
		System.out.println("Available Books :"+management.getAvailableBooksCount());
		System.out.println("-------------------------------------------------");
		System.out.println("Issued Books :"+management.getIssuedBookCount());

	}

}
