package com.training.ui;

import com.training.ds.Stack;
import com.training.ds.StackImpl;
import com.training.model.BillItem;

public class Main10 {

	public static void main(String[] args)  {
		try {
		Stack<BillItem> stack=new StackImpl<>(-5);
		stack.push(new BillItem("Iphone", 10, 50000.00));
		stack.push(new BillItem("Samsung", 14, 44000.00));
		stack.push(new BillItem("Oppo", 150, 25000.00));
		stack.push(new BillItem("Redmi", 5, 35000.00));
		
		System.out.println(stack);
		
		BillItem b=stack.pop();
		System.out.println(b);
		System.out.println(stack);
		System.out.println(b.getItemName()+","+b.getQuantity()+","+b.getPrice()+","+b.getItemValue());

		b=stack.pop();
		System.out.println(b);
		System.out.println(stack);
		System.out.println(b.getItemName()+","+b.getQuantity()+","+b.getPrice()+","+b.getItemValue());
	}catch(Throwable e) {
		System.err.println(e.getMessage());
	}
	}}
