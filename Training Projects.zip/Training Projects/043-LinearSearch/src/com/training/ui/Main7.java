package com.training.ui;

import java.util.Comparator;

import com.training.model.Account;
import com.training.model.comparators.CustomerNameComparator;

public class Main7 {
	
	private static int search(Account[] arr, Account searchObject) {
		
		for (int i = 0; i < arr.length; i++) {
			if (searchObject instanceof Comparable) {
				Comparable searchData = searchObject;
				int r = arr[i].compareTo(searchData);
				if (r == 0)
					return i;
			}
		}
		return -1;
	}
	
	private static int nameSearch(Account[] arr, Account searchObject) {
		Comparator comparator = new CustomerNameComparator();
		for (int i = 0; i < arr.length; i++) {
			int r = comparator.compare(arr[i], searchObject);
			if (r == 0)
				return i;
		}
		return -1;
	}

	private static int balanceSearch(Account[] arr, Account searchObject) {
		
		for(int i=0;i<arr.length;i++) {
			if(arr[i].equals(searchObject))
				return i;
		}
		return -1;
	} 

	public static void main(String[] args) {
		Account acc1=new Account("Rahul", 50000.00);
		Account acc2=new Account("Aju", 123000.00);
		Account acc3=new Account("Manu", 35200.00);
		Account acc4=new Account("Sita", 880000.00);
		
		Account[] account= {acc1,acc2,acc3,acc4};
		
		Account searchObject = new Account("Sita", 50000.00);
		
		System.out.println("------Balance Search with Comparable --------");
		int searchResult=search(account, searchObject);
		if (searchResult == -1)
			System.out.println("Search Data not found");
		else
			System.out.println("Search element " + searchObject + " found in position:" + searchResult);

		
		System.out.println("------Name Search with Comparator--------");
		int nSearchResult = nameSearch(account, searchObject);
		if (nSearchResult == -1)
			System.out.println("Search Data not found");
		else
			System.out.println("Search element " + searchObject + " found in position:" + nSearchResult);

		
		System.out.println("------Name Search with equals--------");
		int bSearchResult = balanceSearch(account, searchObject);
		if (bSearchResult == -1)
			System.out.println("Search Data not found");
		else
			System.out.println("Search element " + searchObject + " found in position:" + bSearchResult);
	}

}
