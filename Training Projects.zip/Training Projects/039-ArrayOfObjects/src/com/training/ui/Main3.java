package com.training.ui;

import com.training.model.BillItem;

public class Main3 {

	public static void main(String[] args) {
		
			BillItem b1=new  BillItem("Redmi",2,44000.00);

			BillItem[] billItems= {	new  BillItem("Samsung",2,15000.00),
									new  BillItem("Nokia",3,12000.00),
									new  BillItem("Oppo",2,32000.00),
									b1
									};
			
			double sum=0;
			for(BillItem item:billItems) {
				System.out.println(item);
				sum=sum+item.getItemValue();
			}
			
			System.out.println("Total bill amount: "+sum);
			
			billItems=null;
			b1=null;
	}

}
