package com.training.ui;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class Main3 {

	public static void main(String[] args) {
		Set<String> set=new HashSet<>();
		
		set.add("Delhi");
		set.add("Mumbai");
		set.add("Kolkata");
		set.add("Pune");
		set.add("Bangalore");
		set.add("Delhi");
		
		System.out.println(set);
		
		System.out.println(set.contains("Mumbai"));
		set.remove("Pune");
		
		Iterator<String> it=set.iterator();
		while(it.hasNext()) {
			String s=it.next();
			System.out.print(s.toUpperCase());
			System.out.print(s.length());
			System.out.println();
		}
		
		set.clear();
		System.out.println(set.isEmpty());
		System.out.println(set.size());

	}

}
