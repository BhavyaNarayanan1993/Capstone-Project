
public class Main1 {
	public static void main(String[] args)
	{
		byte v1=10;  //numeric data type -128 to 127
		System.out.println(Byte.MIN_VALUE);
		System.out.println(Byte.MAX_VALUE);
		
		short v2=15000; //numeric
		System.out.println(Short.MIN_VALUE);
		System.out.println(Short.MAX_VALUE);
		
		int v3=200000; //numeric
		System.out.println(Integer.MIN_VALUE);
		System.out.println(Integer.MAX_VALUE);
		
		long v4=30000000; //numeric
		System.out.println(Long.MIN_VALUE);
		System.out.println(Long.MAX_VALUE);
		
		char v5='A';  //min /u0000      max /uFFFF
		System.out.println(Character.MIN_VALUE);
		System.out.println(Character.MAX_VALUE);
		
		float v6=80.00056f;  //IEEE numeric data with precision
		System.out.println(Float.MIN_VALUE);
		System.out.println(Float.MAX_VALUE);
		
		double v7=8.00056f;  //IEEE numeric data with precision
		System.out.println(Double.MIN_VALUE);
		System.out.println(Double.MAX_VALUE);
		
		boolean v8=true;
		
	}

}
