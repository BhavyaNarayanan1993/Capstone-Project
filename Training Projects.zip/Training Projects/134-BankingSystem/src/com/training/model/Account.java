package com.training.model;

public class Account {
		String accountNumber;
		String accountHolder;
		double balance;
		public Account(String accountNumber, String accountHolder, double balance) {
			super();
			this.accountNumber = accountNumber;
			this.accountHolder = accountHolder;
			this.balance = balance;
		}
		public Account() {
			super();
		}
		public String getAccountNumber() {
			return accountNumber;
		}
		public void setAccountNumber(String accountNumber) {
			this.accountNumber = accountNumber;
		}
		public String getAccountHolder() {
			return accountHolder;
		}
		public void setAccountHolder(String accountHolder) {
			this.accountHolder = accountHolder;
		}
		public double getBalance() {
			return balance;
		}
		public void setBalance(double balance) {
			this.balance = balance;
		}
		
		public void deposit(double amount) {
			this.balance=this.balance+amount;
		}
		
		public void withdraw(double amount) {
			if(this.balance>amount) {
				this.balance=this.balance-amount;
			}
		}
		@Override
		public String toString() {
			return "Account [accountNumber=" + accountNumber + ", accountHolder=" + accountHolder + ", balance="
					+ balance + "]";
		}
		
		
		
}
