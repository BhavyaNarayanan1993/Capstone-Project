package com.training.ui;

public class Main2 {
public static void main(String[] args) {
	
	
	try {
		try {
		System.out.print("I");
		throw new Exception();
		}
		catch(Exception e) {
			System.out.print("Love");
		}
		throw new Exception();
	}
		catch (Exception e) {
			System.out.print("java");
		}	
	
}
}
