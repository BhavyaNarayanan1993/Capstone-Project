package com.training.ui;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import com.training.model.Employee;

public class Main3 {

	public static void main(String[] args) {
		Map<Integer,Employee> empMap=new TreeMap<>();
		
		Employee e1=new Employee(10, "Mani", "Male", "Mumbai", 10000.00);
		Employee e2=new Employee(11, "Surya", "Male", "Pune", 50000.00);
		Employee e3=new Employee(12, "Meena", "Female", "Bangalore", 30000.00);
		Employee e4=new Employee(13, "Manu", "Male", "Kochi", 45000.00);
		Employee e5=new Employee(14, "Priya", "Female", "Trivandrum", 60000.00);

		empMap.put(2,e4);
		empMap.put(Integer.valueOf(3), e3);
		empMap.put(Integer.valueOf(1), e2);
		empMap.put(Integer.valueOf(4), e5);
		empMap.put(Integer.valueOf(5), e1);
		
		System.out.println(empMap);
		
		for(Map.Entry<Integer, Employee> entry:empMap.entrySet()){
			System.out.println(entry.getKey());
			Employee emp=entry.getValue();
			System.out.println(emp.getName()+"-"+emp.getNetSalary());
		}
	}

}
