package com.training.ui;

import com.training.ds.StringStack;

public class Main4 {

	public static void main(String[] args) {
				
		StringStack stack=new StringStack(10);
		stack.push("Delhi");
		stack.push("Kochi");
		stack.push("Bangalore");
		stack.push("Pune");
		stack.push("Trivandrum");
		
		System.out.println(stack);
		
		String r=stack.pop();
		System.out.println(r);
		System.out.println(stack);
		
		r=stack.pop();
		System.out.println(r);
		System.out.println(stack);
		
		r=stack.pop();
		System.out.println(r);
		System.out.println(stack);

	}

}
