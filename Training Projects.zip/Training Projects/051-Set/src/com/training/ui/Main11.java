package com.training.ui;

import com.training.model.Bill;

public class Main11 {

	public static void main(String[] args) {
		
		Bill bill=new Bill(1066,"Manu");
		bill.addBillItem("Dell", 3, 50000.00);
		bill.addBillItem("Samsumg", 2, 55000.00);
		bill.addBillItem("HP", 6, 67000.00);
		bill.addBillItem("Lenova", 4, 80000.00);
		
		bill.printBill();
	}

}
