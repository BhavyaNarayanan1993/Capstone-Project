package pack5;

public class C implements A,B{

	@Override
	public void test3() {
		System.out.println(A.x);
		
	}

	@Override
	public void test1() {
		System.out.println(A.x);
		
	}

	@Override
	public void test2() {
		System.out.println(A.x);
		
	}

	
}
