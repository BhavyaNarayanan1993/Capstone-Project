package com.training.ui;

import com.training.model.Square;

public class Main2 {

	public static void main(String[] args) {
		Square s1=new Square(20);
		Square s2=new Square(20);
		
		int result=s1.compareTo(s2);
		System.out.println(result);
		
		if(result<0)
			System.out.println("Invoking object is less than parameter object");
		if(result>0)
			System.out.println("Invoking object is higher than parameter object");
		if(result==0)
			System.out.println("Invoking object is same as parameter object");

	}

}
