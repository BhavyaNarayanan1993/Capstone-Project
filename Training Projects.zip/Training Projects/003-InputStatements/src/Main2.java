import java.util.Scanner;

public class Main2 {

	public static void main(String[] args) {
		String StudName;
		int mark1,mark2,total;
		float average;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Student name:");
		StudName=sc.nextLine();
		System.out.println("Enter mark1 and mark2:");
		mark1=sc.nextInt();
		mark2=sc.nextInt();
		total=mark1+mark2;
		average=total/2;
		System.out.printf(" Student Name: %s\n Mark1:%d\n Mark2:%d \n Total:%d\n Average:%5.2f",StudName,mark1,mark2,total,average);

	}

}
