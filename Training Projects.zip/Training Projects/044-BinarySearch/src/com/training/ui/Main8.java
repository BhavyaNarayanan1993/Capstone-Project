package com.training.ui;

import java.util.Arrays;
import java.util.Comparator;

import com.training.model.Account;

;

public class Main8 {

	private static int search(Account[] arr, Account searchObject) {

		int low=0,high=arr.length-1;
		while(low<=high) {
			int mid=low+(high-low)/2;
			int r=arr[mid].compareTo(searchObject);
			if(r==0) 
				return mid;
			else if(r<0)
				low=mid+1;
			else
				high=mid-1;
		}
		return -1;
	}
	
	public static void main(String[] args) {
		Account acc1=new Account("Rahul", 50000.00);
		Account acc2=new Account("Aju", 123000.00);
		Account acc3=new Account("Manu", 35200.00);
		Account acc4=new Account("Sita", 880000.00);
		
		Account[] account= {acc1,acc2,acc3,acc4};
		
		Account searchObject = new Account("Sita", 50000.00);
		
		Arrays.sort(account);
		System.out.println(Arrays.toString(account));
		
		int searchResult=search(account, searchObject);
		
		if(searchResult==-1)
			System.out.println(searchObject+"  not found in the array and the result is "+searchResult);
		else
			System.out.println(searchObject+"  found in the array and the position is "+searchResult);
		

	}

}
