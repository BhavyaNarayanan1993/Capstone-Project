package com.training.ui;

import java.util.Arrays;

import com.training.model.Account;
import com.training.model.Person;

public class Main13 {

	public static void main(String[] args) {
		Person person1=new Person("Ram",35);
		Person person2=new Person("Sana",44);
		Person person3=new Person("Raj",18);
		Person person4=new Person("Pooja",22);
		
		Person[] persons= {person1,person2,person3,person4};
		
		int n = persons.length;
		
		for(int i=1;i<n;++i) {
			Person key=persons[i];
			int j=i-1;
			
			int r=persons[j].compareTo(key);
			while(j>=0 && r>0) {
				persons[j+1]=persons[j];
				j=j-1;
				if(j>=0)
					r=persons[j].compareTo(key);
				
			}
			persons[j+1]=key;
		}
		System.out.println(Arrays.toString(persons));
	}

}
