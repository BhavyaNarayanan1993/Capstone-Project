package com.training.ui;

import java.util.ArrayList;
import java.util.List;

public class Main06 {

	public static void main(String[] args) {
		
		List<Float> prices=new ArrayList<>();
		System.out.println(prices);
		System.out.println(prices.size());
		System.out.println(prices.isEmpty());
		
		prices.add(Float.valueOf(66.6f));
		prices.add(Float.valueOf(21.5f));
		prices.add(Float.valueOf(19.2f));
		prices.add(Float.valueOf(22.8f));
		prices.add(Float.valueOf(70.6f));
		prices.add(50.0f);
		prices.add(90.0f);
		prices.add(140.0f);

		Float minval=prices.get(0);
		Float maxval=prices.get(0);
		
		for(int i=1;i<prices.size();i++)
		{
			if(minval>prices.get(i))
				minval=prices.get(i);
			if(maxval<prices.get(i))
				maxval=prices.get(i);
		}
		
		System.out.println("Min Val:"+minval);
		System.out.println("Max Val:"+maxval);		
		}
	

}
