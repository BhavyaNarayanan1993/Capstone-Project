
public class Main3 {

	public static void main(String[] args) {
		
		//character literals
		System.out.println('A');
		System.out.println('a');//\u0061
		System.out.println('7');
		System.out.println('?');
		System.out.println('\t');
		System.out.println('\n');
		
		System.out.println('\u0041');//unicode value     ascii value for chracter A
		System.out.println('\u0061');

	}

}
