package pack2;

public class Z extends Y{
	@Override
	public void test4() {
		// TODO Auto-generated method stub
		
	}


}
