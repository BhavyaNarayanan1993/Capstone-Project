package com.training.linkedlist;

import com.training.model.Customer;

public class LinkedList<T> {
		public static Node start=null;
		
		public void addToList(T data) {
			Node new_node=new Node(data);
			new_node.nextnode=null;
			if(start==null) {
				start=new_node;
			}
			else {
				Node currentNode=start;
				while(currentNode.nextnode!=null) {
					currentNode=currentNode.nextnode;
				}
				currentNode.nextnode=new_node;
			}
		}
		
		public int count() {
			//count the elements in the linked list
			Node currentNode=start;
			int count=0;
			while(currentNode!=null)
			{
				count++;
				currentNode=currentNode.nextnode;
			}
			
			return count;
		}
		
		public void print() {
			Node currentNode=start;
			while(currentNode!=null)
			{
				System.out.println(currentNode.data);
				currentNode=currentNode.nextnode;
			}
		}
		
		public void insertAfter(T after,T data) {
		
			Node currentNode=start;
			Node previousNode=null;
			
			while(currentNode!=null)
			{	
					previousNode=currentNode;
					if(currentNode.data==after) {
						break;
					}
					currentNode=currentNode.nextnode;	
			}
			Node new_node=new Node<T>(data);
			new_node.nextnode=currentNode.nextnode;
			previousNode.nextnode=new_node;
		}
}
