package com.training.ui;

import java.util.Arrays;

public class Main2 {
	
	private static int search(double[] arr,double searchData) {
		
		int low=0,high=arr.length-1;
		while(low<=high) {
			int mid=low+(high-low)/2;
			if(arr[mid]==searchData) 
				return mid;
			else if(arr[mid]<searchData)
				low=mid+1;
			else
				high=mid-1;
		}
		return -1;
	}
	
	public static void main(String[] args) {
		double[] arr= {30.0,22.0,13.0,55.0,11.0,80.0,44.0};
		Arrays.sort(arr);
		System.out.println(Arrays.toString(arr));
		double searchData=13.0;
		int searchResult=search(arr, searchData);
		if(searchResult==-1)
			System.out.println(searchData+"  not found in the array and the result is "+searchResult);
		else
			System.out.println(searchData+"  found in the array and the position is "+searchResult);
		
	}

}
