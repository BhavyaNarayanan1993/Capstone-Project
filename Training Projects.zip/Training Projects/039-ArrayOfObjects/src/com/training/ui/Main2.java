package com.training.ui;

import com.training.model.Square;

public class Main2 {
			public static void main(String[] args) {
				
				Square[] squares=new Square[4];
				
				Square sq1=new Square(4);
				Square sq2=new Square(5);
				squares[0]=sq1;
				squares[1]=sq2;
				squares[2]=new Square(6);
				squares[3]=new Square(7);
				
				for(Square squ:squares) {
					System.out.println("Size is "+squ.getSize()+" Area is: "+squ.getArea());
				}
				
				sq1=sq2=null;
				squares=null;
				
	
}
}
