package com.training.exceptions;

public class StackEmptyException extends Exception{

	public StackEmptyException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public StackEmptyException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public StackEmptyException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public StackEmptyException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public StackEmptyException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
