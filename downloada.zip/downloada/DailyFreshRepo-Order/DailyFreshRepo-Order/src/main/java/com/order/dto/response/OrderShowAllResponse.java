package com.order.dto.response;

import java.util.List;

import com.order.model.Order;

public class OrderShowAllResponse {
	int statusCode;
	String description;
	List<Order> orders;
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public List<Order> getOrders() {
		return orders;
	}
	public void setOrders(List<Order> orders) {
		this.orders = orders;
	}
	@Override
	public String toString() {
		return "OrderShowAllResponse [statusCode=" + statusCode + ", description=" + description + ", orders=" + orders
				+ "]";
	}
	
	
	
}
