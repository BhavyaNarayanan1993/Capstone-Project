package com.training.ds;

import com.training.model.Circle;

public class CircleQueueImpl implements Queue<Circle>{

	@Override
	public void enQueue(Circle Object) throws Throwable {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Circle deQueue() throws Throwable {
		// TODO Auto-generated method stub
		return null;
	}

}
