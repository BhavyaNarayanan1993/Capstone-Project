package com.order.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.order.db.OrderRepository;
import com.order.model.Order;

@Service
public class OrderService {

	@Autowired
	OrderRepository repo;
	
	public Order addNewOrder(Order order) {
		return repo.save(order);
	}
	
	public Order updateOrder(Order order) {
		return repo.save(order);
	}
	
	public Order searchOrder(int id) {
		Optional<Order> optional = repo.findById(id);
		if(optional.isPresent())
			return optional.get();
		else
			return null;
	}

	
	
	public List<Order> getAllOrders(){
		return repo.findAll();
	}
	
	public boolean deleteOrder(Order order) {
		repo.delete(order);
		return true;
	}
	
	
}
