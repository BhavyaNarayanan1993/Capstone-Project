package com.training.ui;

import java.util.Arrays;
import java.util.Comparator;

import com.training.model.BillItem;
import com.training.model.comparators.BillItemPriceComparator;
import com.training.model.comparators.BillItemQuantityComparator;

public class Main6 {


	private static int search(BillItem[] arr, BillItem searchObject) {

		int low=0,high=arr.length-1;
		while(low<=high) {
			int mid=low+(high-low)/2;
			Comparator comparator=new BillItemQuantityComparator();
			int r = comparator.compare(arr[mid], searchObject);
			if(r==0) 
				return mid;
			else if(r<0)
				low=mid+1;
			else
				high=mid-1;
		}
		return -1;
	}

	public static void main(String[] args) {

		BillItem[] billItems = { new BillItem("Nokia", 2, 15000.00),
								new BillItem("Iphone", 1, 78000.00), 
								new BillItem("Oppo", 6, 32000.00),
								new BillItem("Redmi", 7, 44000.00),
								new BillItem("Samsung", 3, 15000.00),
								new BillItem("Vivo", 5, 49000.00) };

		BillItem searchObject = new BillItem("Samsung", 2, 15000.00);

		Arrays.sort(billItems, new BillItemQuantityComparator());
		System.out.println(Arrays.toString(billItems));
		int searchResult = search(billItems, searchObject);
		if (searchResult == -1)
			System.out.println("Search Data not found");
		else
			System.out.println("Search element " + searchObject + " found in position:" + searchResult);

	}

}
