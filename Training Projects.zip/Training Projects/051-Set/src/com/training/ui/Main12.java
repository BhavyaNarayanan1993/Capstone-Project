package com.training.ui;

import com.training.model.Course;

public class Main12 {

	public static void main(String[] args) {
		
		Course course=new Course("Diploma in Web Development");
		course.addCourseItem("HTML", 40, 4500.00);
		course.addCourseItem("CSS", 20, 2500.00);
		course.addCourseItem("jQuery", 35, 6000.00);
		course.addCourseItem("Knockout js", 15, 2000.00);
		course.addCourseItem("Angular", 50, 7500.00);
		
		course.printCourseDetails();
	}

}
