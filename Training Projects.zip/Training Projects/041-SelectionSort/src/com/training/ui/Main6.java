package com.training.ui;

import java.util.Arrays;

import com.training.model.BillItem;
import com.training.model.comparators.BillItemPriceComparator;

public class Main6 {

	public static void main(String[] args) {
		//bill item price
		BillItem b1=new  BillItem("Redmi",2,44000.00);

		BillItem[] billItems= {	new  BillItem("Samsung",2,15000.00),
								new  BillItem("Nokia",3,12000.00),
								new  BillItem("Oppo",2,32000.00),
								b1
								};
		
		int n = billItems.length;

		int imin;
		for (int i = 0; i < n - 1; i++) {
			imin = i;
			for (int j = i + 1; j < n; j++) {
				BillItemPriceComparator comparator=new BillItemPriceComparator();
				int r=comparator.compare(billItems[j], billItems[imin]);
				if (r<0)
					imin = j;
					
			}
			BillItem temp;
			temp = billItems[i];
			billItems[i] = billItems[imin];
			billItems[imin] = temp;

		}
		System.out.println(Arrays.toString(billItems));

	}

}
