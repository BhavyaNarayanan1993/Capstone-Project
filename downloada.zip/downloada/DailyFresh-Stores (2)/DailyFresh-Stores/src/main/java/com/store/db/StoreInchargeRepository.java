package com.store.db;

import org.springframework.data.jpa.repository.JpaRepository;

import com.store.model.StoreIncharge;

public interface StoreInchargeRepository extends JpaRepository<StoreIncharge, Integer>{

}
