package com.training.ui;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

import com.training.model.BillItem;

public class Main8 {

	public static void main(String[] args) {
		Set<BillItem> billItemSet=new TreeSet<>();
		billItemSet.add(new BillItem("Iphone", 3, 60000.00));
		billItemSet.add(new BillItem("Redmi", 4, 80000.00));
		billItemSet.add(new BillItem("Samsung", 5, 30000.00));
		billItemSet.add(new BillItem("Oppo", 1, 70000.00));
		billItemSet.add(new BillItem("Redmi", 8, 40000.00));
		
		System.out.println(billItemSet.size());
		System.out.println(billItemSet);

	}

}
