package com.training.ui;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.training.model.Employee;

public class Main5 {

	public static void main(String[] args) {
		
		Employee e1=new Employee(10, "Mani", "Male", "Chennai", 10000.00);
		Employee e2=new Employee(11, "Surya", "Male", "Cochin", 50000.00);
		Employee e3=new Employee(12, "Meena", "Female", "Bangalore", 30000.00);
		Employee e4=new Employee(13, "Manu", "Male", "Cochin", 45000.00);
		Employee e5=new Employee(14, "Priya", "Female", "Chennai", 60000.00);
		Employee e6=new Employee(15, "Manoj", "Male", "Bangalore", 60000.00);
		Employee e7=new Employee(16, "Santhi", "Female", "Chennai", 44000.00);
		Employee e8=new Employee(17, "Manju", "Female", "Bangalore", 33000.00);
		Employee e9=new Employee(18, "Sanu", "Female", "Cochin", 40000.00);
		Employee e10=new Employee(19, "Pranav", "Male", "Bangalore", 55000.00);
		
		List<Employee> allEmployees=new LinkedList<>();
		allEmployees.add(e1);
		allEmployees.add(e2);
		allEmployees.add(e3);
		allEmployees.add(e4);
		allEmployees.add(e5);
		allEmployees.add(e6);
		allEmployees.add(e7);
		allEmployees.add(e8);
		allEmployees.add(e9);
		allEmployees.add(e10);
		
		Map<String,Integer> cityWiseCountMap=new HashMap<>();
		for(Employee employee:allEmployees) {
			String cityName=employee.getCityName();
			if(cityWiseCountMap.containsKey(cityName)) {
				cityWiseCountMap.put(cityName, cityWiseCountMap.get(cityName)+1);
			}
			else
				cityWiseCountMap.put(cityName, 1);
		}
		//System.out.println(cityWiseCountMap);
		for(Map.Entry<String, Integer> entry:cityWiseCountMap.entrySet()) {
			System.out.println(entry.getKey()+"---"+entry.getValue());
		}
	}

}
