package com.training.ui;

import com.training.ds.SquareStack;
import com.training.model.Square;

public class Main7 {

	public static void main(String[] args) {
		SquareStack stack=new SquareStack(5);
		Square c=new Square(20);
		stack.push(c);
		stack.push(new Square(10));
		stack.push(new Square(30));
		stack.push(new Square(28));
		stack.push(new Square(58));
		
		System.out.println(stack);
		
		Square r=stack.pop();
		System.out.println(r);
		System.out.println(stack);
		
		r=stack.pop();
		System.out.println(r);
		System.out.println(stack);
		
		r=stack.pop();
		System.out.println(r);
		System.out.println(stack);


	}

}
