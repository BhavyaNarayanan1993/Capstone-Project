package com.training.ui;

import java.util.Arrays;

import com.training.model.Square;

public class Main4 {

	public static void main(String[] args) {
		
		Square[] squares=new Square[4];
		
		Square sq1=new Square(34);
		Square sq2=new Square(15);
		squares[0]=sq1;
		squares[1]=sq2;
		squares[2]=new Square(16);
		squares[3]=new Square(27);

		
		for(int i=0;i<squares.length;i++) {
			for (int j=0;j<squares.length-i-1;j++) {
				int r=squares[j].compareTo(squares[j+1]);
				if(r>0)
				{
					Square temp;
					temp=squares[j];
					squares[j]=squares[j+1];
					squares[j+1]=temp;
				}
				
			}
		}
		System.out.println(Arrays.toString(squares));
	}

}
