package com.training.ui;

import java.util.ArrayList;
import java.util.List;

public class Main03 {
		public static void main(String[] args) {
			
			List<Float> prices=new ArrayList<>();
			System.out.println(prices);
			System.out.println(prices.size());
			System.out.println(prices.isEmpty());
			
			prices.add(100.0f);
			prices.add(200.0f);
			prices.add(300.0f);
			prices.add(300.0f);
			prices.add(700.0f);
			prices.add(500.0f);
			prices.add(600.0f);
			prices.add(400.0f);
			
			System.out.println(prices);
			System.out.println(prices.size());
			System.out.println(prices.isEmpty());
			
			System.out.println(prices.contains(500.0f));
			
			System.out.println(prices.get(prices.size()-1));
			System.out.println(prices.get(0));
			System.out.println(prices.indexOf(700.0f));
			
			prices.set(3, 400.0f);
			System.out.println(prices);
			
			prices.remove(1);
			System.out.println(prices);
			
			prices.remove(300.0f);
			System.out.println(prices);
			
			prices.clear();
			
			System.out.println(prices);
			System.out.println(prices.size());
			System.out.println(prices.isEmpty());
			
		}
}
