package pack1;

public interface Student {
		void enroll();
		void takeExam();
		void leave();
		
}
