package com.training.ui;

import java.util.LinkedList;
import java.util.List;

import com.training.model.BillItem;
import com.training.model.Person;

public class Main09 {

	public static void main(String[] args) {
		List<Person> persons= new LinkedList<>();
		persons.add(new Person("Ram",35));
		persons.add(new Person("Sana",44));
		persons.add(new Person("Manu",55));
		persons.add(new Person("Raj",18));
		persons.add(new Person("Pooja",22));
	
		System.out.println("------------------------");
		System.out.println("Sl No\tName\tAge");
		System.out.println("------------------------");
		
		int slno=1;
		Person minagePerson=persons.get(0);
		Person maxagePerson=persons.get(0);
		for (Person p:persons) {
			System.out.println(slno+"\t"+p.getName()+"\t"+p.getAge());
			slno++;
			int a=p.compareTo(minagePerson);
			if(a<0) 
				minagePerson=p;
			a=p.compareTo(maxagePerson);
			if(a>0)
				maxagePerson=p;
		}
		System.out.println("------------------------");		
		System.out.println("Youngest Person: "+minagePerson.getName());
		System.out.println("Eldest Person: "+maxagePerson.getName());
		System.out.println("------------------------");

	}

}
