package com.training.ui;

import com.training.model.Account;

public class Main5 {

	public static void main(String[] args) {
		Account acc=new Account("Manu", 3000.00);
		Account acc1=new Account("Raju", 6000.00);
		
		int a=acc.compareTo(acc1);
		System.out.println(a);
		
		if(a>0)
			System.out.println("Account1 balance is greater than Account2 balance");
		if(a<0)
			System.out.println("Account1 balance is lesser than Account2 balance");
		if(a==0)
			System.out.println("Account1 balance is same as Account2 balance");
	}

}
