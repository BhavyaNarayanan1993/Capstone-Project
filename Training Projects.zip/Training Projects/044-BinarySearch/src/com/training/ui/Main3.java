package com.training.ui;

import java.util.Arrays;

import com.training.model.Circle;

public class Main3 {
	
	private static int search(Circle[] arr,Circle searchData) {
		
		int low=0,high=arr.length-1;
		while(low<=high) {
			int mid=low+(high-low)/2;
			int r=arr[mid].compareTo(searchData);
			if(r==0) 
				return mid;
			else if(r<0)
				low=mid+1;
			else
				high=mid-1;
		}
		return -1;
	}

	public static void main(String[] args) {
		Circle[] circles=new  Circle[5];
		Circle c1=new Circle(10);
		Circle c2=new Circle(5);
		Circle c3=new Circle(15);
		
		circles[0]=c1;
		circles[1]=c2;
		circles[2]=c3;
		circles[3]=new Circle(30);
		circles[4]=new Circle(66);
		
		Circle searchObject=new Circle(30);
		
		Arrays.sort(circles);
		System.out.println(Arrays.toString(circles));
		
		int searchResult=search(circles, searchObject);
		
		if(searchResult==-1)
			System.out.println(searchObject+"  not found in the array and the result is "+searchResult);
		else
			System.out.println(searchObject+"  found in the array and the position is "+searchResult);
		

	}

}
