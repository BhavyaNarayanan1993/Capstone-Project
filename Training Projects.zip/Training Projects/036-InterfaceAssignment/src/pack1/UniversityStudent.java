package pack1;

public class UniversityStudent implements Student{

	@Override
	public void enroll() {
		System.out.println("University Student enroll");
		
	}

	@Override
	public void takeExam() {
		System.out.println("University Student takeExam");
		
	}

	@Override
	public void leave() {
		System.out.println("University Student leave");
		
	}

}
