package pack3;

import pack1.AGradeEmployeeSalaryCalculation;
import pack1.BGradeEmployeeSalaryCalculation;
import pack1.CGradeEmployeeSalaryCalculation;
import pack1.DGradeEmployeeSalaryCalculation;
import pack1.SalaryCalculation;

public class Main1 {

	public static void main(String[] args) {
		SalaryCalculation sal;
		
		sal=new AGradeEmployeeSalaryCalculation();
		
		System.out.println(sal.getAllowance(2000.0));
		System.out.println(sal.getDeduction(2000.0));
		System.out.println(sal.getNetSalary(2000.0));
		
		System.out.println("----------------------------");
		sal=new BGradeEmployeeSalaryCalculation();
		
		System.out.println(sal.getAllowance(2000.0));
		System.out.println(sal.getDeduction(2000.0));
		System.out.println(sal.getNetSalary(2000.0));

		System.out.println("----------------------------");
		sal=new CGradeEmployeeSalaryCalculation();
		
		System.out.println(sal.getAllowance(2000.0));
		System.out.println(sal.getDeduction(2000.0));
		System.out.println(sal.getNetSalary(2000.0));
		
		System.out.println("----------------------------");
		sal=new DGradeEmployeeSalaryCalculation();
		
		System.out.println(sal.getAllowance(2000.0));
		System.out.println(sal.getDeduction(2000.0));
		System.out.println(sal.getNetSalary(2000.0));
	}

}
