package com.training.ui;

import com.training.ds.Stack;
import com.training.ds.StackImpl;
import com.training.model.Employee;
import com.training.model.Manager;
import com.training.model.SalesEmployee;

public class Main13 {

	public static void main(String[] args) {
		try {
		Stack<Employee> stack=new StackImpl<>(10);
		stack.push(new Employee(101,"Manu","MALE","Mumbai",2000.00));
		stack.push(new Manager(102,"Raj","MALE","Pune",2500.0,10));
		stack.push(new SalesEmployee(103,"Meena","FEMALE","Kochi",1000.0,25000.0));
		
		System.out.println(stack);
		
		Employee emp=stack.pop();
		System.out.println(emp);
		System.out.println(stack);
		System.out.println(emp.getId()+","+emp.getName()+","+emp.getGender()+","+emp.getCityName()+","+emp.getBasic()+","+emp.getNetSalary());

		emp=stack.pop();
		System.out.println(emp);
		System.out.println(stack);
		System.out.println(emp.getId()+","+emp.getName()+","+emp.getGender()+","+emp.getCityName()+","+emp.getBasic()+","+emp.getNetSalary());

		emp=stack.pop();
		System.out.println(emp);
		System.out.println(stack);
		System.out.println(emp.getId()+","+emp.getName()+","+emp.getGender()+","+emp.getCityName()+","+emp.getBasic()+","+emp.getNetSalary());
		}catch(Throwable e) {
			System.err.println(e.getMessage());
		}
	}

}
