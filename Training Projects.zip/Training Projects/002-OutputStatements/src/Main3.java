
public class Main3 {

	public static void main(String[] args) {
		int age=30;
		String name="Bhavya";
		
		System.out.printf("My name is %s\n My age is %d",name,age);

	}

}
