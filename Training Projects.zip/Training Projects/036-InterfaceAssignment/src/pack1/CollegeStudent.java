package pack1;

public class CollegeStudent implements Student{

	@Override
	public void enroll() {
		System.out.println("College Student enroll");
		
	}

	@Override
	public void takeExam() {
		System.out.println("College Student takeExam");
		
	}

	@Override
	public void leave() {
		System.out.println("College Student leave");
		
	}

}
