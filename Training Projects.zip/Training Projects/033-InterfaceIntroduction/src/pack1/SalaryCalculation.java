package pack1;

public interface SalaryCalculation {
	
	 double getAllowance(double basic);
	 double getDeduction(double basic);
	 double getNetSalary(double basic);

}
