package com.training.ui;

import java.util.LinkedList;
import java.util.List;

import com.training.model.BillItem;

public class Main08 {

	public static void main(String[] args) {
		List<BillItem> billItems= new LinkedList<>();
		BillItem b1=new  BillItem("Redmi",2,44000.00);

		billItems.add(new  BillItem("Samsung",2,15000.00));
		billItems.add(new  BillItem("IPhone",3,12000.00));
		billItems.add(new  BillItem("Oppo",2,32000.00));
		billItems.add(b1);
							
		System.out.println("------------------------------------------------------------");
		System.out.println("Sl No\tItem Name\tQuantity\tPrice\tValue");
		System.out.println("------------------------------------------------------------");
		int slno=1;
		double total = 0.0;
		for (BillItem b:billItems) {
			total=total+b.getItemValue();
			System.out.println(slno+"\t"+b.getItemName()+"\t\t\t"+b.getQuantity()+"\t"+b.getPrice()+"\t"+b.getItemValue());
			slno++;
		}
		System.out.println("------------------------------------------------------------");
		System.out.println("Total number of items: "+billItems.size()+"\t"+"Bill Amount:"+total);
		System.out.println("------------------------------------------------------------");
	}

}
