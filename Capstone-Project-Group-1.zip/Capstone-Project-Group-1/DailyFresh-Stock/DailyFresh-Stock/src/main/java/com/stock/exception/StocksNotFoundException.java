package com.stock.exception;

public class StocksNotFoundException extends Exception{

	public StocksNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public StocksNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public StocksNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public StocksNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public StocksNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
