package com.training.ui;

import java.util.Arrays;

import com.training.model.Account;
import com.training.model.BillItem;

public class Main8 {

	public static void main(String[] args) {
		Account acc1=new Account("Rahul", 50000.00);
		Account acc2=new Account("Aju", 123000.00);
		Account acc3=new Account("Manu", 35200.00);
		Account acc4=new Account("Sita", 880000.00);
		
		Account[] account= {acc1,acc2,acc3,acc4};
		
		int n = account.length;
		for(int i=1;i<n;++i) {
			Account key=account[i];
			int j=i-1;
			
			int r=account[j].compareTo(key);
			while(j>=0 && r>0) {
				account[j+1]=account[j];
				j=j-1;
				if(j>=0)
					r=account[j].compareTo(key);
				
			}
			account[j+1]=key;
		}
		System.out.println(Arrays.toString(account));

	}

}
