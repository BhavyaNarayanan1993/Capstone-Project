
public class Main2 {

	public static void main(String[] args) {
		int v1=100;
		int v2=100;
		int v3=200;
		
		System.out.println(v1==v2);
		System.out.println(v1==v3);
		
		System.out.println(v1!=v2);
		
		System.out.println(v1<v2);
		System.out.println(v1<v3);
		
		System.out.println(v1<=100);
		
		System.out.println(v3>v2);
		System.out.println(300>=200);
	}

}
