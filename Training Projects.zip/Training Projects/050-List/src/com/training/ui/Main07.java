package com.training.ui;

import java.util.LinkedList;
import java.util.List;

import com.training.model.Circle;

public class Main07 {

	public static void main(String[] args) {
		List<Circle> circles=new LinkedList<Circle>();
		
		circles.add(new Circle(10));
		circles.add(new Circle(60));
		circles.add(new Circle(33));
		circles.add(new Circle(50));
		Circle c1=new Circle(20);
		circles.add(c1);
		
		System.out.println(circles);
		System.out.println(circles.contains(new Circle(10)));
		
		circles.set(1, new Circle(1000));
		System.out.println(circles);
		circles.remove(new Circle(50));
		System.out.println(circles);
		
		Circle minCircle=circles.get(0);
		Circle maxCircle=circles.get(0);
		for(Circle c:circles) {
			int r=c.compareTo(minCircle);
			if(r<0) 
				minCircle=c;
			r=c.compareTo(maxCircle);
			if(r>0)
				maxCircle=c;
			
		}
		System.out.println("Min Circle"+minCircle);
		System.out.println("Max Circle"+maxCircle);
			
		

	}

}
