package pack3;

public interface B extends A {

}
