package com.training.ui;

import java.util.Arrays;

import com.training.model.BillItem;
import com.training.model.comparators.BillItemPriceComparator;
import com.training.model.comparators.BillItemQuantityComparator;

public class Main7 {

	public static void main(String[] args) {
		BillItem b1=new  BillItem("Redmi",2,44000.00);

		BillItem[] billItems= {	new  BillItem("Samsung",4,15000.00),
								new  BillItem("Nokia",3,12000.00),
								new  BillItem("Oppo",6,32000.00),
								b1
								};
		
		int n = billItems.length;

		for(int i=1;i<n;++i) {
			BillItem key=billItems[i];
			int j=i-1;
			BillItemQuantityComparator comparator=new BillItemQuantityComparator();
			int r=comparator.compare(billItems[j], key);
			while(j>=0 && r>0) {
				billItems[j+1]=billItems[j];
				j=j-1;
				if(j>=0)
					r=comparator.compare(billItems[j], key);
				
			}
			billItems[j+1]=key;
		}
		System.out.println(Arrays.toString(billItems));

	}

}
