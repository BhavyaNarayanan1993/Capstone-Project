package com.training.ui;

import com.training.model.BillItem;

public class Main5 {
	
	private static int search(BillItem[] arr, BillItem searchObject) {
		
		for(int i=0;i<arr.length;i++) {
			if(arr[i].equals(searchObject))
				return i;
		}
		return -1;
	}

	public static void main(String[] args) {
		BillItem b1=new  BillItem("Redmi",2,44000.00);

		BillItem[] billItems= {	new  BillItem("Samsung",2,15000.00),
								new  BillItem("Nokia",3,12000.00),
								new  BillItem("Iphone",5,78000.00),
								new  BillItem("Oppo",2,32000.00),
								b1
								};
		
		BillItem searchObject=new BillItem("Iphone", 13, 50000.00);
		int searchResult=search(billItems, searchObject);
		if(searchResult==-1) 
			System.out.println("Search Data not found");
		else
			System.out.println("Search element "+searchObject+" found in position:"+searchResult);

	}

}
