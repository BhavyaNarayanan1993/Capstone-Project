package com.customer.dto.customer.request;

import com.customer.order.dto.OrderDTO;

public class OrderPlaceRequest {
	OrderDTO orderDTO;

	public OrderDTO getOrderDTO() {
		return orderDTO;
	}

	public void setOrderDTO(OrderDTO orderDTO) {
		this.orderDTO = orderDTO;
	}
	
	
}
