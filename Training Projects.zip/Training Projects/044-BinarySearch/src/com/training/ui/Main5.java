package com.training.ui;

import java.util.Arrays;

import com.training.model.BillItem;

public class Main5 {
	
	private static int search(BillItem[] arr,BillItem searchData) {
		
		int low=0,high=arr.length-1;
		while(low<=high) {
			int mid=low+(high-low)/2;
			int r=arr[mid].compareTo(searchData);
			if(r==0) 
				return mid;
			else if(r<0)
				low=mid+1;
			else
				high=mid-1;
		}
		return -1;
	}

	public static void main(String[] args) {
		
		BillItem[] billItems= {	new  BillItem("Samsung",2,15000.00),
								new  BillItem("Nokia",3,12000.00),
								new  BillItem("Iphone",5,78000.00),
								new  BillItem("Oppo",2,32000.00),
								new BillItem("Redmi",2,44000.00)
								};
		
		BillItem searchObject=new BillItem("Iphone", 13, 50000.00);
		
		Arrays.sort(billItems);
		System.out.println(Arrays.toString(billItems));
		
		int searchResult=search(billItems, searchObject);
		
		if(searchResult==-1)
			System.out.println(searchObject+"  not found in the array and the result is "+searchResult);
		else
			System.out.println(searchObject+"  found in the array and the position is "+searchResult);

	}

}
