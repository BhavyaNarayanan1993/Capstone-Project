package com.training.ui;

import java.util.Comparator;

import com.training.model.Employee;
import com.training.model.Manager;
import com.training.model.SalesEmployee;
import com.training.model.comparators.CustomerNameComparator;
import com.training.model.comparators.EmployeeBasicSalaryAscendingComparator;
import com.training.model.comparators.EmployeeBasicSalaryDescendingComparator;

public class Main8 {
	
	private static int search(Employee[] arr, Employee searchObject) {
		
		for (int i = 0; i < arr.length; i++) {
			if (searchObject instanceof Comparable) {
				Comparable searchData = searchObject;
				int r = arr[i].compareTo(searchData);
				if (r == 0)
					return i;
			}
		}
		return -1;
	}
	
	private static int ascendingSearch(Employee[] arr, Employee searchObject) {
		Comparator comparator = new EmployeeBasicSalaryAscendingComparator();
		for (int i = 0; i < arr.length; i++) {
			int r = comparator.compare(arr[i], searchObject);
			if (r == 0)
				return i;
		}
		return -1;
	}

	private static int descendingSearch(Employee[] arr, Employee searchObject) {
		
		Comparator comparator = new EmployeeBasicSalaryDescendingComparator();
		for (int i = 0; i < arr.length; i++) {
			int r = comparator.compare(arr[i], searchObject);
			if (r == 0)
				return i;
		}
		return -1;
	} 

	public static void main(String[] args) {
		Manager manager=new Manager(104, "Ram", "MALE", "Mumbai", 10000.00, 12);
		SalesEmployee salesEmployee1=new SalesEmployee(102, "Dinesh", "MALE", "Delhi", 2000.00, 100000.00);
		SalesEmployee salesEmployee2=new SalesEmployee(103, "Kiran", "MALE", "Pune", 3500.00, 100000.00);
		Employee employee=new Employee(101, "Menaka", "FEMALE", "Cochin", 5000.00);
		
		Employee[] employees= {manager,salesEmployee1,salesEmployee2,employee};

		Employee searchObject=new Employee(103, "Menaka", "FEMALE", "Mumbai", 2000.00);
		
		System.out.println("------Employee Search with Comparable --------");
		int searchResult=search(employees, searchObject);
		if (searchResult == -1)
			System.out.println("Search Data not found");
		else
			System.out.println("Search element " + searchObject + " found in position:" + searchResult);

		
		System.out.println("------Employee Ascending Search with Comparator--------");
		int aSearchResult = ascendingSearch(employees, searchObject);
		if (aSearchResult == -1)
			System.out.println("Search Data not found");
		else
			System.out.println("Search element " + searchObject + " found in position:" + aSearchResult);

		
		System.out.println("------Employee Ascending Search with Comparator--------");
		int dSearchResult = descendingSearch(employees, searchObject);
		if (dSearchResult == -1)
			System.out.println("Search Data not found");
		else
			System.out.println("Search element " + searchObject + " found in position:" + dSearchResult);
		
	}

}
