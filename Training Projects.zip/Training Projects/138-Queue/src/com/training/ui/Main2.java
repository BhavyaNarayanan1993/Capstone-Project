package com.training.ui;

import java.util.PriorityQueue;

public class Main2 {

	public static void main(String[] args) {
		PriorityQueue<Integer> queue;
		queue=new PriorityQueue<>();
		
		queue.add(20);
		queue.add(15);
		queue.add(17);
		queue.add(12);
		queue.add(16);
		for(int i=0;i<3;i++) {
		Integer result=queue.poll();
		System.out.println(result);
		}
	}

}
