package com.customer.dto.customer.request;

import com.customer.model.Customer;

public class CustomerDeleteRequest {
	
	Customer customer;

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	
}
