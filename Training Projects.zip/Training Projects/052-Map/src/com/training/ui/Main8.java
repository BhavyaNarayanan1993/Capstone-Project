package com.training.ui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.training.model.Employee;

public class Main8 {

	public static void main(String[] args) {
		
		Employee e1=new Employee(10, "Mani", "Male", "Chennai", 10000.00);
		Employee e2=new Employee(11, "Surya", "Male", "Cochin", 50000.00);
		Employee e3=new Employee(12, "Meena", "Female", "Bangalore", 30000.00);
		Employee e4=new Employee(13, "Manu", "Male", "Cochin", 45000.00);
		Employee e5=new Employee(14, "Priya", "Female", "Chennai", 60000.00);
		Employee e6=new Employee(15, "Manoj", "Male", "Bangalore", 60000.00);
		Employee e7=new Employee(16, "Santhi", "Female", "Chennai", 44000.00);
		Employee e8=new Employee(17, "Manju", "Female", "Bangalore", 33000.00);
		Employee e9=new Employee(18, "Sanu", "Female", "Cochin", 40000.00);
		Employee e10=new Employee(19, "Pranav", "Male", "Bangalore", 55000.00);
		
		List<Employee> allEmployees=new LinkedList<>();
		allEmployees.add(e1);
		allEmployees.add(e2);
		allEmployees.add(e3);
		allEmployees.add(e4);
		allEmployees.add(e5);
		allEmployees.add(e6);
		allEmployees.add(e7);
		allEmployees.add(e8);
		allEmployees.add(e9);
		allEmployees.add(e10);
		
		Map<String,List<Employee>> map=new HashMap<>();
		for(Employee e:allEmployees) {
			String cityName=e.getCityName();
			if(map.containsKey(cityName)) {
				List<Employee> empList= map.get(cityName);
				empList.add(e);
				
			}else {
				map.put(cityName, new ArrayList());
				List<Employee> empList= map.get(cityName);
				empList.add(e);
			}
		}
		for(Map.Entry<String, List<Employee>> entry:map.entrySet())
		{
			System.out.println("City Name: "+entry.getKey());
			System.out.println("-------------------------------------------------------------------------------------------");
			System.out.println("ID\tName\t\t\tGender\t\tBasic Salary\tNetSalary");
			System.out.println("-------------------------------------------------------------------------------------------");
			List<Employee> empList=entry.getValue();
			int slno=1, cityCount=0;
			double totalBasic=0.0,totalNetSalary=0.0;
			for(Employee e:empList) {
				System.out.printf("%d \t %-20s %-10s \t %10.2f \t %10.2f\n",slno,
						e.getName(),e.getGender(),e.getBasic(),e.getNetSalary());
				totalBasic=totalBasic+e.getBasic();
				totalNetSalary=totalNetSalary+e.getNetSalary();
				cityCount++;
				slno++;
				
			}
			
			System.out.println("-------------------------------------------------------------------------------------------");
			System.out.println("City Count: "+cityCount+"\t\t"+"Total Basic: "+totalBasic+"\t\t"+"Total NetSalary: "+totalNetSalary);
			System.out.println("-------------------------------------------------------------------------------------------");
			System.out.println();
			System.out.println();
		}
	

	}

}
