package com.training.ui;

import java.util.Arrays;

import com.training.model.Account;

public class Main8 {

	public static void main(String[] args) {
		//based on balance
		Account acc1=new Account("Rahul", 50000.00);
		Account acc2=new Account("Aju", 123000.00);
		Account acc3=new Account("Manu", 35200.00);
		Account acc4=new Account("Sita", 880000.00);
		
		Account[] account= {acc1,acc2,acc3,acc4};
		
		int n = account.length;

		int imin;
		for (int i = 0; i < n - 1; i++) {
			imin = i;
			for (int j = i + 1; j < n; j++) {
				int r=account[j].compareTo(account[imin]);
				if(r<0)
					imin = j;
					
			}
			Account temp;
			temp = account[i];
			account[i] = account[imin];
			account[imin] = temp;

		}
		System.out.println(Arrays.toString(account));

	}

}
