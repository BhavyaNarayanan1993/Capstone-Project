package com.bills;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DailyFreshBillsApplication {

	public static void main(String[] args) {
		SpringApplication.run(DailyFreshBillsApplication.class, args);
	}

}
