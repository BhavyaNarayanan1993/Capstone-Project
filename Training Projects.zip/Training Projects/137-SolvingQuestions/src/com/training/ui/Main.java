package com.training.ui;

import java.util.stream.Collectors;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		        String input = "Manu342Verma*4$$";

		        // Separate alphabets
		        String alphabets = input.chars()
		            .filter(Character::isLetter)
		            .mapToObj(c -> String.valueOf((char)c))
		            .collect(Collectors.joining());

		        // Separate special characters (not digit or letter)
		        String specialChars = input.chars()
		            .filter(c -> !Character.isLetterOrDigit(c))
		            .mapToObj(c -> String.valueOf((char)c))
		            .collect(Collectors.joining());
		        
		        String numbers=input.chars()
		        		.filter(Character::isDigit)
		        		.mapToObj(c->String.valueOf((char)c))
		        		.collect(Collectors.joining());
		        
		        int sumOfDigits = input.chars()
		                .filter(Character::isDigit)
		                .map(c -> c - '0') // Convert char digit to actual number
		                .sum();

		        System.out.println(sumOfDigits);
		        System.out.println(numbers);
		        System.out.println("Alphabets: " + alphabets);
		        System.out.println("Special Characters: " + specialChars);
	}

}
